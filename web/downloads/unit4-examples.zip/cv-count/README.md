# 검출 결과 목록으로 개수 세기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


