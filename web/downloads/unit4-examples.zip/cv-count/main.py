from collections import Counter
frames = [["person", "car", "person"], ["person", "car"]]
for i, names in enumerate(frames):
    print("Frame", i, dict(Counter(names)))
# 같은 객체가 다음 프레임에 다시 등장할 수 있으므로 합계는 고유 객체 수가 아닙니다.
