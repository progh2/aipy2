# 실시간 얼굴 검출과 자원 정리

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 opencv-python를 설치하세요.

실제 카메라는 PC에서 직접 실행할 때만 사용합니다. 영상은 저장하지 않습니다.
