import cv2
face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
if face.empty():
    raise RuntimeError("분류기 로드 실패")
cap = cv2.VideoCapture(0)
try:
    if not cap.isOpened():
        raise RuntimeError("카메라 연결과 사용 권한을 확인하세요.")
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        for x,y,w,h in face.detectMultiScale(gray,1.1,5):
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
        cv2.imshow("Faces - press q to quit",frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
finally:
    cap.release()
    cv2.destroyAllWindows()
