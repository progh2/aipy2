faces = [(100, 50, 80, 90), (220, 40, 70, 80)]
print("찾은 얼굴 수:", len(faces))
for i, (x, y, w, h) in enumerate(faces):
    print(f"상자 {i}: 원점 ({x}, {y}) 크기 {w}×{h}")
print("위치만 있습니다. 이름·감정은 이 결과로 단정하지 않습니다.")
eye_in_roi = (12, 18)
origin = faces[0][:2]
eye_on_image = (origin[0] + eye_in_roi[0], origin[1] + eye_in_roi[1])
print("ROI 눈 좌표", eye_in_roi, "→ 원본", eye_on_image)
