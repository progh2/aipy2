import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
loaded = cv2.imread("scene.png")
if loaded is None:
    raise FileNotFoundError("scene.png")
print("shape:", loaded.shape, "size:", loaded.size)
gray = cv2.cvtColor(loaded, cv2.COLOR_BGR2GRAY)
small = cv2.resize(loaded, (130, 90))
center = (loaded.shape[1] / 2, loaded.shape[0] / 2)
matrix = cv2.getRotationMatrix2D(center, 30, 1.0)
rotated = cv2.warpAffine(loaded, matrix, (260, 180))
for name, data in [("gray", gray), ("small", small), ("rotated", rotated)]:
    assert cv2.imwrite(f"result/{name}.png", data)
print("Saved:", sorted(str(p) for p in Path("result").glob("*.png")))
