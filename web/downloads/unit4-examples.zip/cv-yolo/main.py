from ultralytics import YOLO
from pathlib import Path
source = Path("photo.jpg")
if not source.is_file():
    raise FileNotFoundError("사용 허락을 받은 photo.jpg를 준비하세요.")
model = YOLO("yolov8n.pt")
result = model(str(source), device="cpu", conf=0.5)[0]
result.save(filename="detected.jpg")
for box in result.boxes:
    cls = int(box.cls.item())
    print(result.names[cls], round(float(box.conf.item()),3), box.xyxy.tolist())
