# YOLOv8 객체 검출 · 이미지 한 장

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 ultralytics를 설치하세요.

교과서의 YOLOv8 모델을 사용합니다. 첫 실행에 가중치를 내려받으므로 네트워크·디스크 공간이 필요합니다.
