import numpy as np
from skimage import filters
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
img = np.zeros((48, 64))
img[10:35, 15:45] = 1
edges = filters.sobel(img)
fig, axes = plt.subplots(1, 2)
axes[0].imshow(img, cmap="gray")
axes[0].set_title("Original")
axes[1].imshow(edges, cmap="gray")
axes[1].set_title("Sobel")
plt.savefig("sobel.png")
print("Edge maximum:", edges.max())
