# 사람은 맥락, 컴퓨터는 숫자

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


