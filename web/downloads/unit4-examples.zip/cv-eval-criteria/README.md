# 정확도만으로 고르지 않기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


