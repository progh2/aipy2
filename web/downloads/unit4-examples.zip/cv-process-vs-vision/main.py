def blur_value(center, neighbors):
    return round((center + sum(neighbors)) / (1 + len(neighbors)))

detections = [
    {"이름": "네모", "상자": (30, 30, 90, 100)},
    {"이름": "원", "상자": (155, 55, 70, 70)},
]
print("영상 처리 · 가운데 밝기:", blur_value(200, [180, 190, 210]))
print("컴퓨터 비전 · 찾은 것:", [(row["이름"], row["상자"]) for row in detections])
print("다듬은 이미지는 새 그림이고, 검출 결과는 위치와 이름입니다.")
