# 사진을 다듬기 vs 의미를 판단하기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


