import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
outputs = {"mean": cv2.blur(img, (7,7)), "gaussian": cv2.GaussianBlur(img,(7,7),0), "median": cv2.medianBlur(img,7), "canny": cv2.Canny(gray,50,150)}
outputs["equalized"] = cv2.equalizeHist(gray)
outputs["clahe"] = cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8)).apply(gray)
_, outputs["fixed"] = cv2.threshold(gray,127,255,cv2.THRESH_BINARY)
otsu, outputs["otsu"] = cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
outputs["adaptive"] = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,7)
for name, data in outputs.items():
    cv2.imwrite(f"result/{name}.png", data)
print("Otsu threshold:", otsu)
