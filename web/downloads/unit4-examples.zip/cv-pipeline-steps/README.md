# 입력부터 평가까지 한 줄로

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


