# 번호판 위치와 글자는 다른 단계

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


