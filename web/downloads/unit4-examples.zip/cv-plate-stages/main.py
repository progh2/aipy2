plate = {"상자": (40, 80, 120, 36), "글자": "12가3456"}
print("검출 단계 · 위치:", plate["상자"])
print("인식 단계 · 내용:", plate["글자"])
print("위치를 잘 찾아도 글자를 잘못 읽을 수 있습니다. 오류를 단계별로 셉니다.")
found_box = plate["상자"][2] > 0
read_text = len(plate["글자"]) >= 4
print("검출 성공?", found_box, "/ 인식 길이 OK?", read_text)
