# YOLO 웹캠 프레임별 객체 개수

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 ultralytics opencv-python를 설치하세요.

한 프레임 안의 개수입니다. 프레임 합계를 누적 통행 인원으로 해석하지 마세요.
