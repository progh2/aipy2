import cv2
from ultralytics import YOLO
from collections import Counter
model = YOLO("yolov8n.pt")
cap = cv2.VideoCapture(0)
try:
    if not cap.isOpened():
        raise RuntimeError("카메라를 확인하세요.")
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        result = model(frame,device="cpu",conf=0.5,verbose=False)[0]
        counts = Counter(result.names[int(box.cls.item())] for box in result.boxes)
        view = result.plot()
        for row,(name,count) in enumerate(sorted(counts.items())):
            cv2.putText(view,f"{name}: {count}",(10,30+25*row),cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,255,0),2)
        cv2.imshow("Frame counts - q to quit",view)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
finally:
    cap.release()
    cv2.destroyAllWindows()
