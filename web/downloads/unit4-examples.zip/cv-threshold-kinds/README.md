# 고정·분포·주변으로 이진화하기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


