values = [40, 90, 127, 128, 200]
fixed_t = 127
fixed = [255 if v > fixed_t else 0 for v in values]
otsu_t = 100
otsu = [255 if v > otsu_t else 0 for v in values]
block = [40, 90, 200]
local_t = sum(block) / len(block) - 7
adaptive_center = 255 if block[1] > local_t else 0
print("고정 127:", fixed)
print("Otsu 예 100:", otsu, "(실제 Otsu는 분포로 기준을 고름)")
print("적응형 가운데:", adaptive_center, "지역 기준", round(local_t, 1))
print("THRESH_BINARY는 기준과 같으면 0입니다.")
