import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
points = []
preview = img.copy()
def clicked(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN and len(points) < 4:
        points.append([x,y])
        cv2.circle(preview,(x,y),4,(0,0,255),-1)
cv2.namedWindow("Click TL TR BR BL")
cv2.setMouseCallback("Click TL TR BR BL", clicked)
try:
    while len(points) < 4:
        cv2.imshow("Click TL TR BR BL", preview)
        if cv2.waitKey(20) & 0xFF == 27:
            break
    if len(points) == 4:
        src = np.float32(points)
        dst = np.float32([[0,0],[199,0],[199,119],[0,119]])
        if abs(cv2.contourArea(src)) < 10:
            raise ValueError("사각형을 이루는 네 꼭짓점을 순서대로 선택하세요.")
        M = cv2.getPerspectiveTransform(src,dst)
        cv2.imwrite("result/clicked-card.png",cv2.warpPerspective(img,M,(200,120)))
finally:
    cv2.destroyAllWindows()
