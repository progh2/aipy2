# 마우스로 카드 네 꼭짓점 선택

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 numpy opencv-python를 설치하세요.

제공 코드가 실습용 도형 이미지를 직접 생성합니다. result 폴더의 PNG를 열어 결과를 비교하세요. 왼쪽 위→오른쪽 위→오른쪽 아래→왼쪽 아래 순서로 클릭하세요. ESC는 취소입니다.
