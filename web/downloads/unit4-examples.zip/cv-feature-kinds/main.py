jobs = [
    ("밝기가 급변하는 경계", "에지"),
    ("여러 방향으로 바뀌는 위치", "코너"),
    ("이진 영역의 둘레와 면적", "윤곽선"),
]
need = "도형 개수와 면적"
picked = next(name for goal, name in jobs if "면적" in goal)
print("목적:", need)
print("고른 도구:", picked)
for goal, name in jobs:
    print(f"{name}: {goal}")
print("에지를 찾았다고 물체의 종류나 신원을 안 것은 아닙니다.")
