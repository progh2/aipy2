# 선·점·닫힌 경계 고르기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


