import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
cv2.imshow("Scene", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
