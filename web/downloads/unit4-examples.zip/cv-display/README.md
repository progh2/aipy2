# PC 창에서 이미지 보기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 numpy opencv-python를 설치하세요.

제공 코드가 실습용 도형 이미지를 직접 생성합니다. result 폴더의 PNG를 열어 결과를 비교하세요. 창을 닫기 전에 키를 누릅니다. 화면 표시가 가능한 PC 환경이 필요합니다.
