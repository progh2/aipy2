import cv2
from pathlib import Path
image_path = "photo.jpg"  # 사용 허락을 받은 사진을 이 폴더에 넣으세요.
img = cv2.imread(image_path)
if img is None:
    raise FileNotFoundError("photo.jpg 파일을 예제 폴더에 넣으세요.")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
eye = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")
smile = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_smile.xml")
if any(c.empty() for c in [face,eye,smile]):
    raise RuntimeError("분류기 XML 파일을 확인하세요.")
faces = face.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5)
for x,y,w,h in faces:
    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
    roi = gray[y:y+h,x:x+w]
    for classifier,color,neighbors in [(eye,(0,255,0),5),(smile,(0,0,255),20)]:
        for a,b,c,d in classifier.detectMultiScale(roi,1.1,neighbors):
            cv2.rectangle(img,(x+a,y+b),(x+a+c,y+b+d),color,2)
Path("result").mkdir(exist_ok=True)
cv2.imwrite("result/faces.png",img)
print("Faces:",len(faces))
