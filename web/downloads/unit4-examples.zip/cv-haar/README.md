# Haar 얼굴·눈·웃음 검출 · 정적 이미지

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 opencv-python를 설치하세요.

photo.jpg는 직접 준비합니다. 얼굴 위치를 찾는 예제이며 개인의 신원이나 감정을 판정하지 않습니다.
