import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
src = np.float32([[30,30],[220,15],[240,150],[15,160]])
dst = np.float32([[0,0],[199,0],[199,119],[0,119]])
M = cv2.getPerspectiveTransform(src, dst)
result = cv2.warpPerspective(img, M, (200,120))
cv2.imwrite("result/rectified.png", result)
print("Output:", result.shape)
