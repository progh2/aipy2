import cv2
import numpy as np
from pathlib import Path
Path("result").mkdir(exist_ok=True)
img = np.full((180, 260, 3), 235, dtype=np.uint8)
cv2.rectangle(img, (30, 30), (120, 130), (40, 80, 220), -1)
cv2.circle(img, (190, 90), 35, (40, 160, 40), -1)
cv2.imwrite("scene.png", img)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray,50,150)
corners = cv2.goodFeaturesToTrack(gray,50,0.01,10)
marked = img.copy()
if corners is not None:
    for corner in corners:
        x,y = corner.ravel().astype(int)
        cv2.circle(marked,(int(x),int(y)),4,(0,0,255),-1)
_, binary = cv2.threshold(gray,180,255,cv2.THRESH_BINARY_INV)
contours,_ = cv2.findContours(binary,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
outlined = img.copy()
cv2.drawContours(outlined,contours,-1,(0,180,0),2)
for contour in contours:
    print("area:",cv2.contourArea(contour),"box:",cv2.boundingRect(contour))
for name,data in [("edges",edges),("corners",marked),("contours",outlined)]:
    cv2.imwrite(f"result/{name}.png",data)
