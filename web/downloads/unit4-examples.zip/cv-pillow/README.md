# Pillow로 만들기·크기 변경·회전·저장

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 pillow를 설치하세요.


