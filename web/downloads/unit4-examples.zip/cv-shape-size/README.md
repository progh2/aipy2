# shape의 픽셀 수와 size의 원소 수

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


