shape = (2, 3, 3)
height, width, channels = shape
pixels = height * width
size = height * width * channels
print("shape:", shape, "→ 높이", height, "너비", width, "채널", channels)
print("픽셀 수:", pixels)
print("원소 수 size:", size)
print("Pillow.size는 (너비, 높이)이고, OpenCV shape는 (높이, 너비, 채널)입니다.")
