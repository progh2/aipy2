# 사서·교통·검사원 역할 · 이점과 오판

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


