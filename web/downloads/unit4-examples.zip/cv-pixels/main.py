pixels = [[0, 64, 128], [192, 224, 255]]
threshold = 128
inverted = [[255-v for v in row] for row in pixels]
binary = [[255 if v > threshold else 0 for v in row] for row in pixels]
print("height, width:", len(pixels), len(pixels[0]))
print("Inverted:", inverted)
print("Binary:", binary)
