# 작은 이미지의 픽셀·반전·이진화

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


