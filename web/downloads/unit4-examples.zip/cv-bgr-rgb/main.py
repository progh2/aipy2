bgr = (20, 80, 240)

def bgr_to_rgb(pixel):
    b, g, r = pixel
    return (r, g, b)

rgb = bgr_to_rgb(bgr)
print("OpenCV 기본 읽기 BGR:", bgr)
print("화면·Pillow RGB:", rgb)
print("가운데 G는 그대로입니다. 순서를 바꾸지 않으면 빨강과 파랑이 뒤바뀝니다.")
