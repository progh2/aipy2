import wx

def greet(event):
    name = entry.GetValue().strip() or "여러분"
    result.SetLabel(f"{name}님, 안녕하세요!")

def preview(event):
    text = entry.GetValue()
    result.SetLabel(f"미리보기: {text or '빈 칸'}")

app = wx.App()
window = wx.Frame(None, title="이벤트 · wxPython", size=(420, 200))
panel = wx.Panel(window)
layout = wx.BoxSizer(wx.VERTICAL)
entry = wx.TextCtrl(panel)
entry.Bind(wx.EVT_TEXT, preview)
layout.Add(entry, 0, wx.EXPAND | wx.ALL, 12)
button = wx.Button(panel, label="인사하기")
button.Bind(wx.EVT_BUTTON, greet)
layout.Add(button, 0, wx.ALL, 8)
result = wx.StaticText(panel, label="글자를 쓰면 미리보기가 바뀝니다.")
layout.Add(result, 0, wx.ALL, 12)
panel.SetSizer(layout)
window.Show()
app.MainLoop()
