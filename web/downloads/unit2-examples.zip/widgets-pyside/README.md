# PySide6 위젯과 그리기 공간

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 PySide6를 설치하세요.


