from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.widget import Widget

Window.size = (420, 520)

class ColorBlock(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas:
            Color(1, 0.84, 0)
            self.rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._sync, size=self._sync)

    def _sync(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

class WidgetsApp(App):
    def build(self):
        self.title = "Kivy widget gallery"
        box = BoxLayout(orientation="vertical", padding=12, spacing=6)
        box.add_widget(Label(text="Label: short text", font_name=font, size_hint_y=None, height=28))
        box.add_widget(TextInput(multiline=False, font_name=font, size_hint_y=None, height=36))
        box.add_widget(TextInput(multiline=True, font_name=font, size_hint_y=None, height=64))
        row = BoxLayout(size_hint_y=None, height=32)
        self.checked = CheckBox(active=True, size_hint_x=None, width=40)
        row.add_widget(self.checked)
        row.add_widget(Label(text="Done", font_name=font))
        box.add_widget(row)
        for i, value in enumerate(["A", "B"]):
            box.add_widget(ToggleButton(
                text=value, group="pick", font_name=font,
                state="down" if i == 0 else "normal", size_hint_y=None, height=32))
        box.add_widget(Spinner(text="module", values=["module", "package", "GUI"], font_name=font, size_hint_y=None, height=36))
        box.add_widget(ColorBlock(size_hint_y=None, height=48))
        button = Button(text="Print check", font_name=font, size_hint_y=None, height=40)
        button.bind(on_press=lambda btn: print(self.checked.active))
        box.add_widget(button)
        return box

WidgetsApp().run()
