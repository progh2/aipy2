import sys
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

def greet():
    name = entry.text().strip() or "여러분"
    result.setText(f"{name}님, 안녕하세요!")

def preview(text):
    result.setText(f"미리보기: {text or '빈 칸'}")

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("시그널 · PySide6")
window.resize(420, 200)
layout = QVBoxLayout(window)
entry = QLineEdit()
entry.textChanged.connect(preview)
layout.addWidget(entry)
button = QPushButton("인사하기")
button.clicked.connect(greet)
layout.addWidget(button)
result = QLabel("글자를 쓰면 미리보기가 바뀝니다.")
layout.addWidget(result)
window.show()
sys.exit(app.exec())
