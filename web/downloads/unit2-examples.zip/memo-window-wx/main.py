import wx

app = wx.App()
window = wx.Frame(None, title="나만의 메모장 · 창만", size=(640, 420))
panel = wx.Panel(window)
editor = wx.TextCtrl(panel, style=wx.TE_MULTILINE)
layout = wx.BoxSizer(wx.VERTICAL)
layout.Add(editor, 1, wx.EXPAND)
panel.SetSizer(layout)
window.Show()
app.MainLoop()
