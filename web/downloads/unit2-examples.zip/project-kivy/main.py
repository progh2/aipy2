from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from core.logic import roll, days_left, draw

Window.size = (520, 280)

class HelperApp(App):
    def build(self):
        self.title = "Class helper · Kivy"
        box = BoxLayout(orientation="vertical", padding=12, spacing=8)
        self.mode = Spinner(text="Dice", values=["Dice", "D-day", "Draw"], font_name=font, size_hint_y=None, height=40)
        box.add_widget(self.mode)
        box.add_widget(Label(text="sides / YYYY-MM-DD / comma names", font_name=font, size_hint_y=None, height=28))
        self.entry = TextInput(text="6", multiline=False, font_name=font, size_hint_y=None, height=36)
        box.add_widget(self.entry)
        button = Button(text="Run", font_name=font, size_hint_y=None, height=40)
        button.bind(on_press=self.run_task)
        box.add_widget(button)
        self.result = Label(text="Result appears here.", font_name=font)
        box.add_widget(self.result)
        return box

    def run_task(self, button):
        try:
            value = self.entry.text
            mode = self.mode.text
            if mode == "Dice":
                output = str(roll(int(value)))
            elif mode == "D-day":
                output = str(days_left(value)) + " days"
            else:
                output = ", ".join(draw(value.split(","), 1))
            self.result.text = output
        except ValueError as error:
            Popup(title="Check input", content=Label(text=str(error), font_name=font), size_hint=(0.8, 0.4)).open()

HelperApp().run()
