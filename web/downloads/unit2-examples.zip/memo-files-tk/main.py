import tkinter as tk
from tkinter import filedialog

def open_file():
    file_path = filedialog.askopenfilename()
    if not file_path:
        return
    with open(file_path, "r", encoding="utf-8") as file:
        content = file.read()
    text_area.delete("1.0", tk.END)
    text_area.insert(tk.END, content)

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt")
    if not file_path:
        return
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(text_area.get("1.0", "end-1c"))

window = tk.Tk()
window.title("나만의 메모장 · 열기·저장")
window.geometry("640x420")
buttons = tk.Frame(window)
buttons.pack(fill="x")
tk.Button(buttons, text="열기", command=open_file).pack(side="left", padx=4, pady=4)
tk.Button(buttons, text="저장", command=save_file).pack(side="left")
text_area = tk.Text(window, wrap="word")
text_area.pack(expand=True, fill="both")
window.mainloop()
