# 메모장 ② · 열기·저장 버튼

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


