from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.textinput import TextInput

Window.size = (640, 420)

class MemoWindowApp(App):
    def build(self):
        self.title = "Memo · window only"
        self.editor = TextInput(multiline=True, font_name=font)
        return self.editor

MemoWindowApp().run()
