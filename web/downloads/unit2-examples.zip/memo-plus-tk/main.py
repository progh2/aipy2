import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path

class MemoApp:
    def __init__(self, root):
        self.root = root
        self.path = None
        self.dirty = False
        root.geometry("680x440")
        self.text = tk.Text(root, wrap="word", undo=True)
        self.text.pack(expand=True, fill="both")
        self.status = tk.Label(root, anchor="w")
        self.status.pack(fill="x")
        menu = tk.Menu(root)
        root.config(menu=menu)
        file_menu = tk.Menu(menu, tearoff=False)
        menu.add_cascade(label="파일", menu=file_menu)
        file_menu.add_command(label="열기", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="저장", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="다른 이름으로 저장", command=lambda: self.save_file(True))
        file_menu.add_command(label="종료", command=self.close)
        root.bind("<Control-o>", lambda event: self.open_file())
        root.bind("<Control-s>", lambda event: self.save_file())
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.text.bind("<<Modified>>", self.changed)
        self.refresh()

    def refresh(self):
        name = self.path.name if self.path else "제목 없음"
        self.root.title(("* " if self.dirty else "") + name + " · tkinter")
        self.status.config(text=f"{len(self.text.get('1.0', 'end-1c'))}자 · UTF-8")

    def changed(self, event=None):
        if self.text.edit_modified():
            self.dirty = True
            self.text.edit_modified(False)
            self.refresh()

    def confirm_discard(self):
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("미저장 문서", "변경 내용을 저장할까요?")
        if answer is None:
            return False
        return self.save_file() if answer else True

    def open_file(self):
        if not self.confirm_discard():
            return
        name = filedialog.askopenfilename()
        if not name:
            return
        try:
            content = Path(name).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            messagebox.showerror("열기 실패", str(error))
            return
        self.text.delete("1.0", tk.END)
        self.text.insert("1.0", content)
        self.text.edit_modified(False)
        self.path, self.dirty = Path(name), False
        self.refresh()

    def save_file(self, save_as=False):
        target = self.path
        if target is None or save_as:
            name = filedialog.asksaveasfilename(defaultextension=".txt")
            if not name:
                return False
            target = Path(name)
        try:
            target.write_text(self.text.get("1.0", "end-1c"), encoding="utf-8")
        except (OSError, UnicodeError) as error:
            messagebox.showerror("저장 실패", str(error))
            return False
        self.path, self.dirty = target, False
        self.text.edit_modified(False)
        self.refresh()
        return True

    def close(self):
        if self.confirm_discard():
            self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = MemoApp(root)
    root.mainloop()
