import sys
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel,
    QLineEdit, QCheckBox, QRadioButton, QPushButton, QButtonGroup)

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("입력 폼 · PySide6")
window.resize(420, 260)
layout = QVBoxLayout(window)
layout.addWidget(QLabel("이름을 입력하세요."))
entry = QLineEdit()
layout.addWidget(entry)
done = QCheckBox("오늘 실습 완료")
layout.addWidget(done)
group = QButtonGroup(window)
for value in ["1학년", "2학년", "3학년"]:
    radio = QRadioButton(value)
    group.addButton(radio)
    layout.addWidget(radio)
group.buttons()[0].setChecked(True)
result = QLabel("값을 읽고 아래에 표시합니다.")
layout.addWidget(result)

def show_choice():
    extra = "완료" if done.isChecked() else "미완료"
    picked = group.checkedButton()
    grade = picked.text() if picked else "?"
    result.setText(f"{entry.text().strip() or '이름 없음'} · {grade} · {extra}")

button = QPushButton("선택 확인")
button.clicked.connect(show_choice)
layout.addWidget(button)
window.show()
sys.exit(app.exec())
