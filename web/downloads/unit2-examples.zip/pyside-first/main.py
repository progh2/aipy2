import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("첫 창 · PySide6")
window.resize(360, 160)
layout = QVBoxLayout(window)
layout.addWidget(QLabel("QApplication → 창 → show → exec"))
window.show()
sys.exit(app.exec())
