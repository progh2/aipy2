import wx

app = wx.App()
window = wx.Frame(None, title="체크와 라디오", size=(420, 240))
panel = wx.Panel(window)
layout = wx.BoxSizer(wx.VERTICAL)
done = wx.CheckBox(panel, label="오늘 실습 완료")
layout.Add(done, 0, wx.ALL, 8)
radios = []
for i, value in enumerate(["1학년", "2학년", "3학년"]):
    style = wx.RB_GROUP if i == 0 else 0
    radio = wx.RadioButton(panel, label=value, style=style)
    radios.append(radio)
    layout.Add(radio, 0, wx.LEFT | wx.BOTTOM, 12)
result = wx.StaticText(panel, label="체크는 여러 개, 라디오는 하나.")
layout.Add(result, 0, wx.ALL, 8)

def show_choice(event):
    extra = "완료" if done.GetValue() else "미완료"
    grade = next((item.GetLabel() for item in radios if item.GetValue()), "?")
    result.SetLabel(f"{grade} · {extra}")

button = wx.Button(panel, label="선택 확인")
button.Bind(wx.EVT_BUTTON, show_choice)
layout.Add(button, 0, wx.ALL, 8)
panel.SetSizer(layout)
window.Show()
app.MainLoop()
