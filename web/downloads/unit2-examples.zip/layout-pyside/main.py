import sys
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton
app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("Qt 레이아웃")
window.resize(520, 300)
vertical = QVBoxLayout(window)
horizontal = QHBoxLayout()
for name in ["열기", "저장", "종료"]:
    horizontal.addWidget(QPushButton(name))
vertical.addLayout(horizontal)
grid = QGridLayout()
for i in range(6):
    grid.addWidget(QPushButton(str(i + 1)), i // 3, i % 3)
vertical.addLayout(grid)
window.show()
sys.exit(app.exec())
