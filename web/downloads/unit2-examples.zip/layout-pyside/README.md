# PySide6 · 수평·수직·격자 배치

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 PySide6를 설치하세요.


