# Label·Entry · 한 줄 읽고 보여 주기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


