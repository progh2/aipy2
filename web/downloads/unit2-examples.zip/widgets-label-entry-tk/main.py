import tkinter as tk

def show_name():
    name = entry.get().strip() or "이름 없음"
    result.config(text=f"입력한 이름: {name}")

root = tk.Tk()
root.title("Label과 Entry")
root.geometry("420x180")
tk.Label(root, text="이름을 입력하세요.").pack(pady=8)
entry = tk.Entry(root)
entry.pack(fill="x", padx=24)
tk.Button(root, text="표시", command=show_name).pack(pady=8)
result = tk.Label(root, text="아직 입력이 없습니다.")
result.pack()
root.mainloop()
