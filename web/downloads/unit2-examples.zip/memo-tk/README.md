# 교과서 메모장 · tkinter 전체 코드

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


