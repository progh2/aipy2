name = input("이름: ").strip() or "여러분"
print(f"{name}님, 안녕하세요!")
