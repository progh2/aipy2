import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QMainWindow, QPlainTextEdit, QFileDialog, QMessageBox
from PySide6.QtGui import QAction, QKeySequence

class MemoWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.path = None
        self.resize(680, 440)
        self.editor = QPlainTextEdit()
        self.setCentralWidget(self.editor)
        menu = self.menuBar().addMenu("파일")
        for label, handler, key in [
            ("열기", self.open_file, QKeySequence.StandardKey.Open),
            ("저장", self.save_file, QKeySequence.StandardKey.Save),
            ("다른 이름으로 저장", lambda: self.save_file(True), QKeySequence.StandardKey.SaveAs),
            ("종료", self.close, QKeySequence.StandardKey.Quit),
        ]:
            action = QAction(label, self)
            action.setShortcut(QKeySequence(key))
            # triggered(bool)의 checked를 save_as로 잘못 전달하지 않도록 감쌉니다.
            action.triggered.connect(lambda checked=False, fn=handler: fn())
            menu.addAction(action)
        self.editor.textChanged.connect(self.refresh)
        self.editor.document().modificationChanged.connect(self.refresh)
        self.refresh()

    def refresh(self):
        name = self.path.name if self.path else "제목 없음"
        dirty = self.editor.document().isModified()
        self.setWindowTitle(("* " if dirty else "") + name + " · PySide6")
        self.statusBar().showMessage(f"{len(self.editor.toPlainText())}자 · UTF-8")

    def confirm_discard(self):
        if not self.editor.document().isModified():
            return True
        B = QMessageBox.StandardButton
        answer = QMessageBox.question(self, "미저장 문서", "변경 내용을 저장할까요?", B.Save | B.Discard | B.Cancel)
        if answer == B.Cancel:
            return False
        return self.save_file() if answer == B.Save else True

    def open_file(self):
        if not self.confirm_discard():
            return
        name, _ = QFileDialog.getOpenFileName(self, "열기", "", "텍스트 (*.txt);;모든 파일 (*)")
        if not name:
            return
        try:
            content = Path(name).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            QMessageBox.warning(self, "열기 실패", str(error))
            return
        self.path = Path(name)
        self.editor.setPlainText(content)
        self.editor.document().setModified(False)
        self.refresh()

    def save_file(self, save_as=False):
        target = self.path
        if target is None or save_as:
            name, _ = QFileDialog.getSaveFileName(self, "저장", "memo.txt", "텍스트 (*.txt)")
            if not name:
                return False
            target = Path(name)
        try:
            target.write_text(self.editor.toPlainText(), encoding="utf-8")
        except (OSError, UnicodeError) as error:
            QMessageBox.warning(self, "저장 실패", str(error))
            return False
        self.path = target
        self.editor.document().setModified(False)
        self.refresh()
        return True

    def closeEvent(self, event):
        if self.confirm_discard():
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MemoWindow()
    window.show()
    sys.exit(app.exec())
