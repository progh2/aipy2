import sys
from PySide6.QtWidgets import (QApplication, QWidget, QGridLayout, QLabel,
    QLineEdit, QPushButton)

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("격자 폼 · PySide6")
window.resize(420, 180)
grid = QGridLayout(window)
grid.addWidget(QLabel("아이디"), 0, 0)
grid.addWidget(QLineEdit(), 0, 1)
grid.addWidget(QLabel("비밀번호"), 1, 0)
secret = QLineEdit()
secret.setEchoMode(QLineEdit.EchoMode.Password)
grid.addWidget(secret, 1, 1)
grid.addWidget(QPushButton("로그인"), 2, 0, 1, 2)
window.show()
sys.exit(app.exec())
