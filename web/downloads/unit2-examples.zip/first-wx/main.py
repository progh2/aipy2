import wx

app = wx.App()
window = wx.Frame(None, title="첫 창 · wxPython", size=(360, 160))
panel = wx.Panel(window)
layout = wx.BoxSizer(wx.VERTICAL)
layout.Add(wx.StaticText(panel, label="wx.App → Frame → Show → MainLoop"), 0, wx.ALL, 24)
panel.SetSizer(layout)
window.Show()
app.MainLoop()
