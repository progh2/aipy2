import tkinter as tk
from tkinter import messagebox
from core.logic import roll, days_left, draw

def run_task():
    try:
        if mode.get() == "주사위":
            result.set(str(roll(int(entry.get()))))
        elif mode.get() == "D-day":
            result.set(str(days_left(entry.get())) + "일")
        else:
            result.set(", ".join(draw(entry.get().split(","), 1)))
    except ValueError as error:
        messagebox.showwarning("입력 확인", str(error))
root = tk.Tk()
root.title("우리 반 생활 도우미 · tkinter")
root.geometry("520x280")
mode = tk.StringVar(value="주사위")
for name in ["주사위", "D-day", "추첨"]:
    tk.Radiobutton(root, text=name, variable=mode, value=name).pack(anchor="w")
tk.Label(root, text="면 수 / YYYY-MM-DD / 쉼표로 나눈 이름을 입력하세요.").pack()
entry = tk.Entry(root)
entry.insert(0, "6")
entry.pack(fill="x", padx=16)
tk.Button(root, text="실행", command=run_task).pack(pady=12)
result = tk.StringVar(value="결과가 여기에 표시됩니다.")
tk.Label(root, textvariable=result).pack()
root.mainloop()
