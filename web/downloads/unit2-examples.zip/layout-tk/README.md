# tkinter · 같은 입력 폼의 pack·grid·place 비교

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.

교과서 밖 보강 예제입니다. 넓게·좁게를 번갈아 누르세요. 고정 좌표 place의 오른쪽이 잘리고, pack·grid 입력칸은 주어진 너비에 맞춰 변합니다.
