import tkinter as tk
root = tk.Tk()
root.title("배치 비교")
root.geometry("520x400")
# 서로 다른 부모 Frame 안에서 배치 방식을 비교합니다.
for kind in ["pack", "grid", "place"]:
    frame = tk.LabelFrame(root, text=kind, height=110)
    frame.pack(fill="x", padx=16, pady=8)
    if kind == "pack":
        for value in ["A", "B", "C"]:
            tk.Button(frame, text=value).pack(side="left", expand=True, fill="x")
    elif kind == "grid":
        for i, value in enumerate(["A", "B", "C"]):
            tk.Button(frame, text=value).grid(row=0, column=i, sticky="ew")
            frame.columnconfigure(i, weight=1)
    else:
        for i, value in enumerate(["A", "B", "C"]):
            tk.Button(frame, text=value).place(x=20 + i*80, y=10)
root.mainloop()
