import tkinter as tk
root = tk.Tk()
root.title("창 크기를 바꾸어 배치 비교")
root.geometry("560x590")
controls = tk.Frame(root)
controls.pack(fill="x", padx=12, pady=8)
tk.Button(controls, text="넓게", command=lambda: root.geometry("560x590")).pack(side="left")
tk.Button(controls, text="좁게", command=lambda: root.geometry("340x590")).pack(side="left")
# 같은 두 입력칸과 확인 버튼입니다. 부모 Frame마다 배치를 나눕니다.
for kind in ["pack", "grid", "place"]:
    frame = tk.LabelFrame(root, text=kind, height=150)
    frame.pack(fill="x", padx=12, pady=8)
    if kind == "pack":
        for title in ["이름", "학번"]:
            row = tk.Frame(frame)
            row.pack(fill="x", padx=8, pady=6)
            tk.Label(row, text=title, width=6).pack(side="left")
            tk.Entry(row, width=8).pack(side="left", expand=True, fill="x")
        tk.Button(frame, text="확인").pack(fill="x", padx=8, pady=8)
    elif kind == "grid":
        frame.columnconfigure(1, weight=1)
        for row, title in enumerate(["이름", "학번"]):
            tk.Label(frame, text=title).grid(row=row, column=0, sticky="e", padx=8, pady=6)
            tk.Entry(frame, width=8).grid(row=row, column=1, sticky="ew", padx=8)
        tk.Label(frame, text="두 칸 모두\n입력하세요").grid(row=0, column=2, rowspan=2, sticky="ns", padx=8)
        tk.Button(frame, text="확인").grid(row=2, column=0, columnspan=3, sticky="ew", padx=8, pady=8)
    else:
        # 좌표와 너비를 고정하면 좁은 창에서 입력칸·버튼이 잘립니다.
        for row, title in enumerate(["이름", "학번"]):
            tk.Label(frame, text=title).place(x=8, y=8 + row*36)
            tk.Entry(frame).place(x=80, y=8 + row*36, width=400)
        tk.Button(frame, text="확인").place(x=8, y=90, width=472)
root.mainloop()
