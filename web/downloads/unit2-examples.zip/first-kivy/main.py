from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label

Window.size = (480, 220)

class FirstApp(App):
    def build(self):
        self.title = "First window · Kivy"
        box = BoxLayout(padding=24)
        box.add_widget(Label(text="App -> build() -> run()", font_name=font))
        return box

FirstApp().run()
