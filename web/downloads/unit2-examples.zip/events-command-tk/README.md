# Button.command · 올바른 연결과 잘못된 연결

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


