import tkinter as tk

def greet():
    log.insert(tk.END, "클릭할 때 인사\n")

def too_early():
    log.insert(tk.END, "버튼을 만들기 전에 이미 실행됨\n")

root = tk.Tk()
root.title("command 전달 비교")
root.geometry("420x240")
log = tk.Text(root, height=8)
log.pack(fill="both", expand=True, padx=8, pady=8)
tk.Button(root, text="올바른 연결 command=greet", command=greet).pack(fill="x", padx=8)
tk.Button(root, text="잘못된 연결 command=too_early()", command=too_early()).pack(fill="x", padx=8, pady=8)
log.insert(tk.END, "창이 열린 직후 기록을 보세요.\n")
root.mainloop()
