import sys
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QComboBox,
    QLabel, QLineEdit, QPushButton, QMessageBox)
from core.logic import roll, days_left, draw

class HelperWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("우리 반 생활 도우미 · PySide6")
        self.resize(520, 280)
        layout = QVBoxLayout(self)
        self.mode = QComboBox()
        self.mode.addItems(["주사위", "D-day", "추첨"])
        layout.addWidget(self.mode)
        layout.addWidget(QLabel("면 수 / YYYY-MM-DD / 쉼표로 나눈 이름"))
        self.entry = QLineEdit("6")
        layout.addWidget(self.entry)
        button = QPushButton("실행")
        button.clicked.connect(self.run_task)
        layout.addWidget(button)
        self.result = QLabel("결과가 여기에 표시됩니다.")
        layout.addWidget(self.result)

    def run_task(self):
        try:
            value = self.entry.text()
            mode = self.mode.currentText()
            if mode == "주사위":
                output = str(roll(int(value)))
            elif mode == "D-day":
                output = str(days_left(value)) + "일"
            else:
                output = ", ".join(draw(value.split(","), 1))
            self.result.setText(output)
        except ValueError as error:
            QMessageBox.warning(self, "입력 확인", str(error))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = HelperWindow()
    window.show()
    sys.exit(app.exec())
