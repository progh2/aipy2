from core.logic import roll, days_left, draw
from datetime import date
print("주사위:", roll(6))
print("남은 날짜:", days_left("2026-12-25", date(2026, 12, 24)))
print("추첨:", draw(["민지", "수빈", "하늘"], 2))
