from datetime import date
import random

def roll(sides):
    if sides < 1:
        raise ValueError("면 수는 1 이상이어야 합니다.")
    return random.randint(1, sides)

def days_left(target, today=None):
    today = today or date.today()
    return (date.fromisoformat(target) - today).days

def draw(names, count):
    names = list(dict.fromkeys(name.strip() for name in names if name.strip()))
    if not 1 <= count <= len(names):
        raise ValueError("추첨 수를 명단 인원 안에서 정하세요.")
    return random.sample(names, count)
