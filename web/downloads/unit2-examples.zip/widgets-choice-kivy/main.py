from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.togglebutton import ToggleButton

Window.size = (420, 280)

class ChoiceApp(App):
    def build(self):
        self.title = "Check and toggle"
        box = BoxLayout(orientation="vertical", padding=16, spacing=8)
        row = BoxLayout(size_hint_y=None, height=36)
        self.done = CheckBox(active=False, size_hint_x=None, width=40)
        row.add_widget(self.done)
        row.add_widget(Label(text="Practice done", font_name=font))
        box.add_widget(row)
        self.grades = []
        for i, value in enumerate(["Grade 1", "Grade 2", "Grade 3"]):
            toggle = ToggleButton(
                text=value, group="grade", font_name=font,
                state="down" if i == 0 else "normal", size_hint_y=None, height=36)
            self.grades.append(toggle)
            box.add_widget(toggle)
        self.result = Label(text="Check is independent. Toggle group picks one.", font_name=font)
        box.add_widget(self.result)
        button = Button(text="Read choice", font_name=font, size_hint_y=None, height=40)
        button.bind(on_press=self.show_choice)
        box.add_widget(button)
        return box

    def show_choice(self, button):
        extra = "done" if self.done.active else "not done"
        grade = next((item.text for item in self.grades if item.state == "down"), "?")
        self.result.text = f"{grade} · {extra}"

ChoiceApp().run()
