import sys
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

def greet():
    name = entry.text().strip() or "여러분"
    result.setText(f"{name}님, 안녕하세요!")

def reset():
    entry.clear()
    result.setText("이름을 입력하세요.")

app = QApplication(sys.argv)
window = QWidget()
window.setWindowTitle("인사 실습 · PySide6")
window.resize(480, 260)
layout = QVBoxLayout(window)
layout.addWidget(QLabel("나의 첫 GUI"))
entry = QLineEdit()
layout.addWidget(entry)
button = QPushButton("인사하기")
button.clicked.connect(greet)
layout.addWidget(button)
clear_button = QPushButton("초기화")
clear_button.clicked.connect(reset)
layout.addWidget(clear_button)
result = QLabel("이름을 입력하세요.")
layout.addWidget(result)
window.show()
sys.exit(app.exec())
