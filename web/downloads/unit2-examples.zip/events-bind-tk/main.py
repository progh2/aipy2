import tkinter as tk

def greet(event=None):
    name = entry.get().strip() or "여러분"
    result.config(text=f"{name}님, 안녕하세요!")

root = tk.Tk()
root.title("bind · Enter 키")
root.geometry("420x180")
entry = tk.Entry(root)
entry.pack(fill="x", padx=20, pady=12)
entry.bind("<Return>", greet)
tk.Button(root, text="인사하기", command=greet).pack()
result = tk.Label(root, text="이름을 쓰고 Enter를 눌러 보세요.")
result.pack(pady=12)
entry.focus()
root.mainloop()
