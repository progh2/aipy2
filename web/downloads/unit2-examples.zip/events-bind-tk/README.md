# bind · Enter 키로 같은 함수 호출

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


