import tkinter as tk

window = tk.Tk()
window.title("나만의 메모장 · 창만")
window.geometry("640x420")
text_area = tk.Text(window, wrap="word")
text_area.pack(expand=True, fill="both")
window.mainloop()
