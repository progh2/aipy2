from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from pathlib import Path
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

Window.size = (640, 420)

class MemoApp(App):
    def build(self):
        self.title = "Memo · Kivy"
        self.path = Path("memo.txt")
        root = BoxLayout(orientation="vertical", padding=8, spacing=8)
        bar = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=40)
        for name, handler in [("Open", self.open_file), ("Save", self.save_file), ("Clear", self.clear_text)]:
            button = Button(text=name, font_name=font)
            button.bind(on_press=handler)
            bar.add_widget(button)
        root.add_widget(bar)
        self.editor = TextInput(multiline=True, font_name=font)
        root.add_widget(self.editor)
        self.status = Label(text="Buttons write memo.txt in this folder.", font_name=font, size_hint_y=None, height=28)
        root.add_widget(self.status)
        return root

    def open_file(self, button):
        if not self.path.exists():
            self.status.text = "No memo.txt yet. Save first or cancel stays empty."
            return
        try:
            self.editor.text = self.path.read_text(encoding="utf-8")
            self.status.text = "Opened memo.txt"
        except (OSError, UnicodeError) as error:
            self.status.text = "Open failed: " + str(error)

    def save_file(self, button):
        try:
            self.path.write_text(self.editor.text, encoding="utf-8")
            self.status.text = "Saved memo.txt"
        except (OSError, UnicodeError) as error:
            self.status.text = "Save failed: " + str(error)

    def clear_text(self, button):
        self.editor.text = ""
        self.status.text = "Cleared. File is unchanged until Save."

MemoApp().run()
