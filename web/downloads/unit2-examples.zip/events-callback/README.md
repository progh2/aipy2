# 콜백 · 지금 호출 vs 나중에 호출

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


