def greet():
    print("인사를 실행했습니다.")
    return "반환값"

print("1) command=greet() 처럼 지금 호출하면")
wrong = greet()
print("저장된 값:", wrong)

print("2) command=greet 처럼 함수 자체를 저장하면")
right = greet
print("아직 두 번째 인사는 없습니다.")
print("클릭을 흉내 내어 호출합니다.")
right()
print("저장된 값은 함수 객체입니다:", right.__name__)
