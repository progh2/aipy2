# StaticText·TextCtrl · 한 줄 읽고 보여 주기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 wxPython를 설치하세요.

브라우저(Pyodide)에는 wxPython이 없어 창이 뜨지 않습니다. 웹에서는 문법 확인과 코드·실행 화면으로 배우고, PC에서 python -m pip install wxPython 후 python main.py로 실행하세요.
