import wx

def show_name(event):
    name = entry.GetValue().strip() or "이름 없음"
    result.SetLabel(f"입력한 이름: {name}")

app = wx.App()
window = wx.Frame(None, title="StaticText와 TextCtrl", size=(420, 180))
panel = wx.Panel(window)
layout = wx.BoxSizer(wx.VERTICAL)
layout.Add(wx.StaticText(panel, label="이름을 입력하세요."), 0, wx.ALL, 8)
entry = wx.TextCtrl(panel)
layout.Add(entry, 0, wx.EXPAND | wx.ALL, 12)
button = wx.Button(panel, label="표시")
button.Bind(wx.EVT_BUTTON, show_name)
layout.Add(button, 0, wx.ALL, 8)
result = wx.StaticText(panel, label="아직 입력이 없습니다.")
layout.Add(result, 0, wx.ALL, 8)
panel.SetSizer(layout)
window.Show()
app.MainLoop()
