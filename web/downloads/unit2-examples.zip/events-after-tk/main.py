import tkinter as tk

root = tk.Tk()
root.title("after 타이머")
root.geometry("420x180")
label = tk.Label(root, text="3초 뒤에 인사합니다.", font=("sans-serif", 16))
label.pack(padx=24, pady=24)

def tick(left):
    if left == 0:
        label.config(text="안녕하세요! after가 호출했습니다.")
        return
    label.config(text=f"{left}초 남았습니다.")
    root.after(1000, lambda: tick(left - 1))

tk.Button(root, text="카운트 시작", command=lambda: tick(3)).pack()
root.mainloop()
