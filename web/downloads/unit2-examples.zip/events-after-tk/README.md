# after · 이벤트 루프를 막지 않는 타이머

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


