# Qt Designer · .ui 불러와 이벤트 연결

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 PySide6를 설치하세요.

form.ui는 Designer가 저장하는 XML입니다. 이 예제는 실행 때 QUiLoader로 읽습니다. pyside6-uic로 파이썬을 만드는 경로와 결과 화면은 같습니다.
