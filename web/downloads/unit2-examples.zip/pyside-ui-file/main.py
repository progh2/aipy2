import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QFile
from PySide6.QtUiTools import QUiLoader

app = QApplication(sys.argv)
ui_path = Path(__file__).with_name("form.ui")
ui_file = QFile(str(ui_path))
ui_file.open(QFile.OpenModeFlag.ReadOnly)
window = QUiLoader().load(ui_file)
ui_file.close()

def greet():
    name = window.nameEdit.text().strip() or "여러분"
    window.resultLabel.setText(f"{name}님, 안녕하세요!")

window.greetButton.clicked.connect(greet)
window.show()
sys.exit(app.exec())
