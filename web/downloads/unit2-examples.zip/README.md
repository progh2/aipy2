각 예제의 폴더를 따로 열어 실행하세요. tkinter는 일부 Linux에서 python3-tk 설치가 필요합니다.
웹 예제의 input 값은 사이트에 안내되어 있습니다. 실행 인자 sys 예제: python main.py param1 param2
