import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QMainWindow, QPlainTextEdit, QFileDialog, QMessageBox
from PySide6.QtGui import QAction

class MemoWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("나만의 메모장 · PySide6")
        self.resize(640, 420)
        self.editor = QPlainTextEdit()
        self.setCentralWidget(self.editor)
        menu = self.menuBar().addMenu("파일")
        for title, handler in [("열기", self.open_file), ("저장", self.save_file), ("종료", self.close)]:
            action = QAction(title, self)
            action.triggered.connect(handler)
            menu.addAction(action)

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "열기", "", "텍스트 (*.txt);;모든 파일 (*)")
        if not path:
            return
        try:
            self.editor.setPlainText(Path(path).read_text(encoding="utf-8"))
        except (OSError, UnicodeError) as error:
            QMessageBox.warning(self, "열기 실패", str(error))

    def save_file(self):
        path, _ = QFileDialog.getSaveFileName(self, "저장", "memo.txt", "텍스트 (*.txt)")
        if not path:
            return
        try:
            Path(path).write_text(self.editor.toPlainText(), encoding="utf-8")
        except (OSError, UnicodeError) as error:
            QMessageBox.warning(self, "저장 실패", str(error))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MemoWindow()
    window.show()
    sys.exit(app.exec())
