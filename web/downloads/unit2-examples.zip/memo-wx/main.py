import wx
from pathlib import Path

class MemoFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title="나만의 메모장 · wxPython", size=(640, 420))
        panel = wx.Panel(self)
        self.editor = wx.TextCtrl(panel, style=wx.TE_MULTILINE)
        layout = wx.BoxSizer(wx.VERTICAL)
        layout.Add(self.editor, 1, wx.EXPAND)
        panel.SetSizer(layout)
        menubar = wx.MenuBar()
        file_menu = wx.Menu()
        open_item = file_menu.Append(wx.ID_OPEN, "열기	Ctrl+O")
        save_item = file_menu.Append(wx.ID_SAVE, "저장	Ctrl+S")
        file_menu.AppendSeparator()
        exit_item = file_menu.Append(wx.ID_EXIT, "종료")
        menubar.Append(file_menu, "파일")
        self.SetMenuBar(menubar)
        self.Bind(wx.EVT_MENU, self.open_file, open_item)
        self.Bind(wx.EVT_MENU, self.save_file, save_item)
        self.Bind(wx.EVT_MENU, self.on_exit, exit_item)

    def open_file(self, event):
        with wx.FileDialog(self, "열기", wildcard="텍스트 (*.txt)|*.txt|모든 파일 (*.*)|*.*",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dialog:
            if dialog.ShowModal() == wx.ID_CANCEL:
                return
            path = dialog.GetPath()
        try:
            self.editor.SetValue(Path(path).read_text(encoding="utf-8"))
        except (OSError, UnicodeError) as error:
            wx.MessageBox(str(error), "열기 실패", wx.OK | wx.ICON_WARNING)

    def save_file(self, event):
        with wx.FileDialog(self, "저장", wildcard="텍스트 (*.txt)|*.txt",
                           defaultFile="memo.txt",
                           style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as dialog:
            if dialog.ShowModal() == wx.ID_CANCEL:
                return
            path = dialog.GetPath()
        try:
            Path(path).write_text(self.editor.GetValue(), encoding="utf-8")
        except (OSError, UnicodeError) as error:
            wx.MessageBox(str(error), "저장 실패", wx.OK | wx.ICON_WARNING)

    def on_exit(self, event):
        self.Close()

if __name__ == "__main__":
    app = wx.App()
    window = MemoFrame()
    window.Show()
    app.MainLoop()
