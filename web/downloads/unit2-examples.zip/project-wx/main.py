import wx
from core.logic import roll, days_left, draw

class HelperFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title="우리 반 생활 도우미 · wxPython", size=(520, 280))
        panel = wx.Panel(self)
        layout = wx.BoxSizer(wx.VERTICAL)
        self.mode = wx.Choice(panel, choices=["주사위", "D-day", "추첨"])
        self.mode.SetSelection(0)
        layout.Add(self.mode, 0, wx.EXPAND | wx.ALL, 8)
        layout.Add(wx.StaticText(panel, label="면 수 / YYYY-MM-DD / 쉼표로 나눈 이름"), 0, wx.ALL, 8)
        self.entry = wx.TextCtrl(panel, value="6")
        layout.Add(self.entry, 0, wx.EXPAND | wx.ALL, 8)
        button = wx.Button(panel, label="실행")
        button.Bind(wx.EVT_BUTTON, self.run_task)
        layout.Add(button, 0, wx.ALL, 8)
        self.result = wx.StaticText(panel, label="결과가 여기에 표시됩니다.")
        layout.Add(self.result, 0, wx.ALL, 8)
        panel.SetSizer(layout)

    def run_task(self, event):
        try:
            value = self.entry.GetValue()
            mode = self.mode.GetStringSelection()
            if mode == "주사위":
                output = str(roll(int(value)))
            elif mode == "D-day":
                output = str(days_left(value)) + "일"
            else:
                output = ", ".join(draw(value.split(","), 1))
            self.result.SetLabel(output)
        except ValueError as error:
            wx.MessageBox(str(error), "입력 확인", wx.OK | wx.ICON_WARNING)

if __name__ == "__main__":
    app = wx.App()
    window = HelperFrame()
    window.Show()
    app.MainLoop()
