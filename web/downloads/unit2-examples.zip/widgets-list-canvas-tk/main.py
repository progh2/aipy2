import tkinter as tk

def show_pick():
    selected = listbox.curselection()
    if not selected:
        result.config(text="항목을 먼저 고르세요.")
        return
    name = listbox.get(selected[0])
    result.config(text=f"선택한 주제: {name}")
    canvas.delete("all")
    canvas.create_text(120, 30, text=name, font=("sans-serif", 14))

root = tk.Tk()
root.title("목록과 캔버스")
root.geometry("420x280")
listbox = tk.Listbox(root, height=4)
for value in ["모듈", "패키지", "GUI"]:
    listbox.insert(tk.END, value)
listbox.pack(fill="x", padx=16, pady=8)
canvas = tk.Canvas(root, width=240, height=60, bg="white")
canvas.create_oval(10, 10, 50, 50, fill="gold")
canvas.pack()
tk.Button(root, text="선택 그리기", command=show_pick).pack(pady=8)
result = tk.Label(root, text="목록에서 고른 뒤 버튼을 누르세요.")
result.pack()
root.mainloop()
