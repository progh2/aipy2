from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from pathlib import Path
# 한글 표시: 실행 폴더에 NotoSansKR.ttf를 넣거나 PC의 한글 글꼴 경로를 지정하세요.
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
Window.size = (480, 300)
class GreetingApp(App):
    def build(self):
        self.title = "Greeting · Kivy"
        box = BoxLayout(orientation="vertical", padding=16, spacing=8)
        box.add_widget(Label(text="My first GUI", font_name=font))
        self.entry = TextInput(multiline=False, font_name=font)
        box.add_widget(self.entry)
        button = Button(text="Greet", font_name=font)
        button.bind(on_press=self.greet)
        box.add_widget(button)
        reset = Button(text="Reset", font_name=font)
        reset.bind(on_press=self.reset)
        box.add_widget(reset)
        self.result = Label(text="Enter your name.", font_name=font)
        box.add_widget(self.result)
        return box
    def greet(self, button):
        self.result.text = "Hello, " + (self.entry.text.strip() or "everyone") + "!"
    def reset(self, button):
        self.entry.text = ""
        self.result.text = "Enter your name."
GreetingApp().run()
