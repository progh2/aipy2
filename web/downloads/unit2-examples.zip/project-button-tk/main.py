import tkinter as tk
from core.logic import roll

def show():
    result.config(text=f"주사위: {roll(6)}")

root = tk.Tk()
root.title("기능 연결 · 주사위")
root.geometry("360x160")
tk.Button(root, text="굴리기", command=show).pack(pady=20)
result = tk.Label(root, text="버튼을 누르면 core.logic.roll을 호출합니다.")
result.pack()
root.mainloop()
