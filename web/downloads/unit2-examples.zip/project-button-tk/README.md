# 기능 모듈 한 줄 연결 · 주사위 버튼

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


