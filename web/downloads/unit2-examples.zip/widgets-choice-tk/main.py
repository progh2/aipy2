import tkinter as tk

def show_choice():
    extra = "완료" if done.get() else "미완료"
    print(done.get(), grade.get(), extra)
    result.config(text=f"{grade.get()} · {extra}")

root = tk.Tk()
root.title("체크와 라디오")
root.geometry("420x240")
done = tk.BooleanVar()
tk.Checkbutton(root, text="오늘 실습 완료", variable=done).pack(anchor="w", padx=16, pady=8)
grade = tk.StringVar(value="1학년")
for value in ["1학년", "2학년", "3학년"]:
    tk.Radiobutton(root, text=value, variable=grade, value=value).pack(anchor="w", padx=16)
tk.Button(root, text="선택 확인", command=show_choice).pack(pady=8)
result = tk.Label(root, text="체크는 여러 개, 라디오는 하나.")
result.pack()
root.mainloop()
