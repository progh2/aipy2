import tkinter as tk

root = tk.Tk()
root.title("grid · 로그인 폼")
root.geometry("420x200")
frame = tk.Frame(root, padx=16, pady=16)
frame.pack(fill="both", expand=True)
frame.columnconfigure(1, weight=1)
tk.Label(frame, text="아이디").grid(row=0, column=0, sticky="e", padx=6, pady=6)
tk.Entry(frame).grid(row=0, column=1, sticky="ew")
tk.Label(frame, text="비밀번호").grid(row=1, column=0, sticky="e", padx=6, pady=6)
tk.Entry(frame, show="*").grid(row=1, column=1, sticky="ew")
tk.Button(frame, text="로그인").grid(row=2, column=0, columnspan=2, sticky="ew", pady=8)
root.mainloop()
