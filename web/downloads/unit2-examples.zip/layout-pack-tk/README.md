# pack · expand와 fill

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


