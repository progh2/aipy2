import tkinter as tk

root = tk.Tk()
root.title("pack · expand와 fill")
root.geometry("420x240")
tk.Label(root, text="위쪽은 가로만 늘어남", bg="#dbeafe").pack(fill="x")
tk.Button(root, text="가운데는 남은 공간을 채움", bg="#fef3c7").pack(expand=True, fill="both", padx=8, pady=8)
tk.Button(root, text="아래도 가로는 채움").pack(fill="x")
root.mainloop()
