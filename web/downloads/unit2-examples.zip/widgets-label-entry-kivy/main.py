from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

Window.size = (420, 180)

class LabelEntryApp(App):
    def build(self):
        self.title = "Label and TextInput"
        box = BoxLayout(orientation="vertical", padding=16, spacing=8)
        box.add_widget(Label(text="Enter a name.", font_name=font, size_hint_y=None, height=32))
        self.entry = TextInput(multiline=False, font_name=font, size_hint_y=None, height=36)
        box.add_widget(self.entry)
        button = Button(text="Show", font_name=font, size_hint_y=None, height=40)
        button.bind(on_press=self.show_name)
        box.add_widget(button)
        self.result = Label(text="No input yet.", font_name=font)
        box.add_widget(self.result)
        return box

    def show_name(self, button):
        name = self.entry.text.strip() or "no name"
        self.result.text = "Name: " + name

LabelEntryApp().run()
