from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

Window.size = (520, 260)

class LayoutApp(App):
    def build(self):
        self.title = "Kivy layout"
        vertical = BoxLayout(orientation="vertical", padding=12, spacing=8)
        horizontal = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=44)
        for name in ["Open", "Save", "Quit"]:
            horizontal.add_widget(Button(text=name, font_name=font))
        vertical.add_widget(horizontal)
        grid = GridLayout(cols=2, spacing=8, size_hint_y=None, height=96)
        grid.add_widget(Label(text="ID", font_name=font))
        grid.add_widget(TextInput(multiline=False, font_name=font))
        grid.add_widget(Label(text="Password", font_name=font))
        grid.add_widget(TextInput(multiline=False, password=True, font_name=font))
        vertical.add_widget(grid)
        return vertical

LayoutApp().run()
