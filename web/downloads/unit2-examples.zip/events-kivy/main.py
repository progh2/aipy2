from pathlib import Path
font = "NotoSansKR.ttf"
if not Path(font).exists():
    font = "Roboto"
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

Window.size = (420, 200)

class EventsApp(App):
    def build(self):
        self.title = "Events · Kivy"
        box = BoxLayout(orientation="vertical", padding=16, spacing=8)
        self.entry = TextInput(multiline=False, font_name=font, size_hint_y=None, height=36)
        self.entry.bind(text=self.preview)
        box.add_widget(self.entry)
        button = Button(text="Greet", font_name=font, size_hint_y=None, height=40)
        button.bind(on_press=self.greet)
        box.add_widget(button)
        self.result = Label(text="Type to see a preview.", font_name=font)
        box.add_widget(self.result)
        return box

    def greet(self, button):
        name = self.entry.text.strip() or "everyone"
        self.result.text = f"Hello, {name}!"

    def preview(self, widget, value):
        self.result.text = f"Preview: {value or 'empty'}"

EventsApp().run()
