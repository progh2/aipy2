# bind · on_press와 text

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 Kivy를 설치하세요.

브라우저(Pyodide)에는 Kivy가 없어 창이 뜨지 않습니다. 웹에서는 문법 확인과 코드·실행 화면으로 배우고, PC에서 python -m pip install kivy 후 python main.py로 실행하세요. 기본 글꼴은 한글을 가정하지 않습니다. 실행 폴더에 NotoSansKR.ttf를 넣으면 한국어 문구로 바꿀 수 있습니다.
