import tkinter as tk

def say_hello():
    label.config(text="반갑습니다!")

root = tk.Tk()
root.title("처음부터 만들기")
label = tk.Label(root, text="버튼을 눌러 보세요.")
label.pack(pady=12)
tk.Button(root, text="인사", command=say_hello).pack()
root.mainloop()
