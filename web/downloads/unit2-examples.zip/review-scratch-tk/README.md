# 확인학습 · 창·버튼·콜백을 처음부터

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


