# 표준 라이브러리로 먼저 해결

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


