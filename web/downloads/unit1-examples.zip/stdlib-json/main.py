import json
data = {"scores": [70, 80, 90]}
text = json.dumps(data, ensure_ascii=False)
print(text)
print(json.loads(text)["scores"])
