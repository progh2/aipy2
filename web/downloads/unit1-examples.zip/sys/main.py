import sys
print("실행 파일명 :", sys.argv[0])
for i, value in enumerate(sys.argv[1:], start=1):
    print("인자", i, ":", value)
sys.exit()
print("이 줄은 실행되지 않습니다.")
