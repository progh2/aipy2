# 교과서 os 예제 · PC 명령

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.

교과서의 dir는 Windows 명령입니다. 이 예제는 macOS/Linux에서 ls를 선택하도록 보완했습니다.
