# 패키지 임포트 4

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


