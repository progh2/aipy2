import random
n = int(input("주사위 면 수: "))
if n < 1:
    print("면 수는 1 이상이어야 합니다.")
else:
    print("주사위 값:", random.randrange(1, n + 1))
