# 종합 평가 · n면 주사위

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


