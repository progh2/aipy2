import numpy as np
scores = np.array([70, 80, 90])
print(scores.mean())
