# PC · NumPy 첫 실습

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 numpy를 설치하세요.

가상환경에서 python -m pip install -r requirements.txt를 실행하세요.
