# 기능 모듈 한 함수만 검사

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


