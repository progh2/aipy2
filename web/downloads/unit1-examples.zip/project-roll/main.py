from core.logic import roll
print("6면:", roll(6))
print("20면:", roll(20))
