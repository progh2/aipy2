import calculator
import counter
print("합:", calculator.add(3, 5))
print("하나 증가:", counter.add(1))
