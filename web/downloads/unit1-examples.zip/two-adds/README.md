# 같은 이름 add, 다른 모듈

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


