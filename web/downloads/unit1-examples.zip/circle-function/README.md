# 함수 정의와 호출 분리

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


