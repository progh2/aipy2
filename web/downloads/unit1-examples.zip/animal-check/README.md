# 35쪽 확인학습 · 동물 패키지

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


