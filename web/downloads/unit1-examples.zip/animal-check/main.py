from nature.animals import *
bird.wild()
lion.wild()
