from nature.animals.lion import wild
wild()
