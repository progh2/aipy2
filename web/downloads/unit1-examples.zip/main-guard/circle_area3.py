PI = 3.14
print("circle_area3의 이름:", __name__)

def circlearea(r):
    print("반지름이 {}인 원의 넓이: {}".format(r, r*r*PI))

if __name__ == "__main__":
    circlearea(4)
