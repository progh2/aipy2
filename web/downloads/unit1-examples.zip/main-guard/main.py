import circle_area3
print("main.py의 이름:", __name__)
circle_area3.circlearea(3)
