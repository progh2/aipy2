# 직접 실행과 임포트 비교

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


