import addcal
import subcal
print("두 수의 합 :", addcal.addnum(5, 3))
print("두 수의 차 :", subcal.subnum(7, 2))
