def addnum(a, b):
    return a + b
print("두 수의 합 :", addnum(1, 3))
