# 종합 평가 8 · 출력 추적

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


