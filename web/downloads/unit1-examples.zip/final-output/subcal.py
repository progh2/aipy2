def subnum(a, b):
    return a - b
if __name__ == "__main__":
    print("두 수의 차 :", subnum(4, 1))
