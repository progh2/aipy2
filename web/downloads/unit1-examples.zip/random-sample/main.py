import random
random.seed(7)
names = ["민지", "수빈", "하늘", "지우"]
picked = random.sample(names, 2)
print("추첨:", picked)
print("원본:", names)
copied = names.copy()
random.shuffle(copied)
print("섞은 복사본:", copied)
print("원본 유지:", names)
