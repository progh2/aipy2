import random
random.seed(42)
first = [random.randrange(1, 7) for _ in range(5)]
random.seed(42)
second = [random.randrange(1, 7) for _ in range(5)]
print(first)
print(second)
print("같은가?", first == second)
