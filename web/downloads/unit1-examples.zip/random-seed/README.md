# 시드를 고정하면 같은 난수

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


