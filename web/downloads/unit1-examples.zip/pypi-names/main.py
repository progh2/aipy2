pairs = [
    ("beautifulsoup4", "bs4", "HTML에서 정보 추출"),
    ("pillow", "PIL", "이미지 크기·형식"),
    ("numpy", "numpy", "배열·수치 계산"),
    ("scikit-learn", "sklearn", "머신러닝"),
]
print("설치 이름 → import 이름")
for install, imported, use in pairs:
    print(f"{install:16} → {imported:8}  ({use})")
print("pip 명령은 터미널에서 실행합니다. 코드 입력창이 아닙니다.")
