from datetime import date
today = date.today()
target = date(today.year, 12, 25)
if target < today:
    target = date(today.year + 1, 12, 25)
print("다음 크리스마스까지", (target - today).days, "일")
