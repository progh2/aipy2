import random
presents = ["문구용품", "과자", "인형"]
print(random.choice(presents))
