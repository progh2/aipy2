# 탐구 · 선물 하나 고르기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


