import circle_area2
circle_area2.circlearea(3)
