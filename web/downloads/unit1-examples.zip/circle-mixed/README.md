# 함수와 실행문이 함께 있을 때

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


