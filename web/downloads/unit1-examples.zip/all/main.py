from nature.plants import *
tree.wild()
# flower.wild()  # 주석을 해제하고 실행하세요.
# from nature.plants import flower  # 명시적 임포트는 가능합니다.
