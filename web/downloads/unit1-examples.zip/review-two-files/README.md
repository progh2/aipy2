# 처음부터 두 파일 만들고 호출

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


