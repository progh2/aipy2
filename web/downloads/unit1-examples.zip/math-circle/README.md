# math.pi로 원 넓이

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


