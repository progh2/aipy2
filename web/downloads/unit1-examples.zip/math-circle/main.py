import math

def circle_area(r):
    return math.pi * r ** 2

print(circle_area(3))
print("소수 둘째 자리:", round(circle_area(3), 2))
print("거듭제곱 연산자:", 2 ** 10, " / math.pow:", math.pow(2, 10))
