import math
print("파이:", math.pi)
print("e:", math.e)
print("올림:", math.ceil(3.5))
print("내림:", math.floor(3.5))
print("팩토리얼:", math.factorial(5))
print("최대 공약수:", math.gcd(28, 70))
print("거듭제곱:", math.pow(2, 10))
print("음수의 올림·내림:", math.ceil(-3.5), math.floor(-3.5))
