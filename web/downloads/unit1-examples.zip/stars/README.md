# 25쪽 탐구 · 별 출력

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


