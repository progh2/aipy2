def makestar(c, r):
    for i in range(r):
        print("*" * c)

if __name__ == "__main__":
    makestar(4, 3)
