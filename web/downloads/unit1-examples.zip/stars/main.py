from star import makestar
makestar(4, 3)
import star as s
s.makestar(2, 2)
