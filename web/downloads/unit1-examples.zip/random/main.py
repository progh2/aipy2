import random
print(random.random())
print(random.uniform(2.5, 10.0))
print(random.randrange(10))
print(random.randrange(1, 7, 2))
season = ["봄", "여름", "가을", "겨울"]
print(random.choice(season))
letters = ["가", "나", "다", "라", "마"]
result = random.shuffle(letters)
print("원본:", letters, "반환값:", result)
print(random.sample(list(range(1, 10)), 3))
