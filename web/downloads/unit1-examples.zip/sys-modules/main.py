import sys
print("sys.path[0] (지금 폴더):", sys.path[0])
print("불러오기 전 math:", "math" in sys.modules)
import math
print("불러온 뒤 math:", "math" in sys.modules)
import math
print("두 번째 import 뒤에도 pi:", math.pi)
