def hello():
    print("안녕히 가세요")
