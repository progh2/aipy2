# 같은 함수 이름 · 별칭으로 구별

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


