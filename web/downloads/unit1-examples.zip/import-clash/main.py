from greet import hello
from farewell import hello as bye_hello
hello()
bye_hello()
