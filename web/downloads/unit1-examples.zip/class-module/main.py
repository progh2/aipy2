from shapes import Circle
print(Circle(3).area())
