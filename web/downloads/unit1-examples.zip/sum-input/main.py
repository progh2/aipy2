from sumnummod import sumnum
print("두 수의 합 :", sumnum())
