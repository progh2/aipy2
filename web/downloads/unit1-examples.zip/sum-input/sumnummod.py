def sumnum():
    n1 = int(input("첫 번째 수: "))
    n2 = int(input("두 번째 수: "))
    return n1 + n2

if __name__ == "__main__":
    print(sumnum())
