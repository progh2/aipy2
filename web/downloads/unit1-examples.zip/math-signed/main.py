import math
print("양수 3.5 → ceil", math.ceil(3.5), "/ floor", math.floor(3.5))
print("음수 -3.5 → ceil", math.ceil(-3.5), "/ floor", math.floor(-3.5))
print("0에 가까운 쪽이 올림인가?", math.ceil(-3.5) == -3)
