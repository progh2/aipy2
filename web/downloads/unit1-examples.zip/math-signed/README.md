# 음수에서 올림과 내림

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


