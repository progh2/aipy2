from datetime import datetime
now = datetime.now()
print(now)
print(now.year, now.month, now.day)
print(now.hour, now.minute, now.second)
print("요일 번호:", now.weekday())
week = "월화수목금토일"[now.weekday()]
print(f"오늘은 {now.year}년 {now.month}월 {now.day}일 {week}요일입니다.")
start = datetime(now.year, 1, 1)
print("올해 지난 시간:", now - start)
