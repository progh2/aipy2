import rectEx1
rectEx1.rect(2, 4)
