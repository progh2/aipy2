# 탐구 활동 · 사각형 모듈

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


