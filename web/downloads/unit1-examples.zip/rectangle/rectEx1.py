def rect(width, height):
    print("가로가 {} 세로가 {}인 사각형의 넓이: {}".format(width, height, width*height))

if __name__ == "__main__":
    rect(3, 5)
