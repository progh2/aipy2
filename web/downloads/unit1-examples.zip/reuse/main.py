import calculator
print(calculator.add(3, 5))
print(calculator.add(10, -2))
