# 한 번 만든 함수를 두 프로그램에서 사용하기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


