def add(a, b):
    return a + b

print("숙제1:", add(3, 5))
