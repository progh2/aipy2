import homework1
import homework2
print("두 숙제가 각자 add를 가지고 있습니다.")
