# 같은 함수를 두 파일에 복사하면

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


