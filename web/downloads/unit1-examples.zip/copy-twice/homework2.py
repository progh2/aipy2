def add(a, b):
    return a + b

print("숙제2:", add(10, -2))
