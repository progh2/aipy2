import os
print("운영체제:", os.name)
print("현재 폴더:", os.getcwd())
os.makedirs("practice", exist_ok=True)
with open("practice/note.txt", "w", encoding="utf-8") as f:
    f.write("모듈 실습")
print(os.listdir("practice"))
