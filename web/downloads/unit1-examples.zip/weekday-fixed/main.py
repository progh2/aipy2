from datetime import date
day = date(2026, 9, 15)
week = "월화수목금토일"
print(day.isoformat(), week[day.weekday()] + "요일")
print("weekday()는 월요일 0:", day.weekday())
print("일요일은 6:", date(2026, 9, 20).weekday())
