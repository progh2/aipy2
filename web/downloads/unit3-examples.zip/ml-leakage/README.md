# 미래 정답을 X에 넣으면

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


