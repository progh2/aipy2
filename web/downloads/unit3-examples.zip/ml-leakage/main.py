honest = {"어제_대출": 12, "시험기간": 1}
leaky = {"어제_대출": 12, "시험기간": 1, "다음날_대출": 28}
print("정직한 X:", honest)
print("새어 나간 X:", leaky)
print("예측 시점에는 다음날_대출을 모릅니다. 테스트 점수만 높아집니다.")
available_at_predict_time = set(honest)
print("누수?", "다음날_대출" in leaky and "다음날_대출" not in available_at_predict_time)
