layers = [
    ("인공지능", "가장 넓은 범위", "비밀번호 길이 검사"),
    ("머신러닝", "데이터로 패턴을 배움", "스팸 분류"),
    ("딥러닝", "여러 층의 신경망", "이미지 특징 학습"),
]
for name, meaning, example in layers:
    print(f"{name}: {meaning} · 예: {example}")
print("포함 관계: 인공지능 ⊃ 머신러닝 ⊃ 딥러닝")
