from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
pipe = make_pipeline(StandardScaler(), KNeighborsClassifier())
print("CV:", cross_val_score(pipe, X_train, y_train, cv=3))
search = GridSearchCV(pipe, {"kneighborsclassifier__n_neighbors": [3, 5, 7]}, cv=3, scoring="accuracy", n_jobs=1)
search.fit(X_train, y_train)
print("Best:", search.best_params_, search.best_score_)
print("Final test:", search.score(X_test, y_test))
