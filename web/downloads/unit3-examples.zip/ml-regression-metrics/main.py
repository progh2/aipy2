import pandas as pd
import numpy as np              # 수치 계산을 위한 numpy 라이브러리
from sklearn.datasets import fetch_california_housing    # 회귀 예제 데이터 세트
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression        # 선형 회귀 모델
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
                                         # 회귀 평가 지표 함수들

housing = fetch_california_housing()
X = pd.DataFrame(housing.data, columns=housing.feature_names)
y = pd.Series(housing.target)   # 주택 가격 (연속형)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"\n - 평균 제곱 오차 (MSE): {mse:.4f}")
print(f" - 평균 절대 오차 (MAE): {mae:.4f}")
print(f" - 결정계수 (R-squared): {r2:.4f}")
