# 교과서 122~123쪽 regression_metrics.py — 캘리포니아 주택 가격 MSE·MAE·R²

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 scikit-learn pandas numpy를 설치하세요.

전체 scikit-learn 모델은 PC에서 실행합니다. 브라우저에서는 연결된 원리 실습으로 입력·계산·결과를 먼저 확인하세요. 첫 실행에 캘리포니아 주택 데이터 다운로드가 필요해 PC/코랩에서 실행하세요.
