import pandas as pd
from sklearn.datasets import load_diabetes            # 예제 데이터 세트 (회귀)
from sklearn.linear_model import LinearRegression     # 예시 모델
from sklearn.model_selection import cross_val_score # 교차 검증 함수
import numpy as np                                    # 평균 계산을 위해

diabetes = load_diabetes()
X = pd.DataFrame(diabetes.data, columns=diabetes.feature_names) # 특징 데이터
y = pd.Series(diabetes.target)                        # 목표 변수 데이터

linear_model = LinearRegression()                     # 선형 회귀 모델 객체 생성
scores = cross_val_score(linear_model, X, y, scoring='r2', cv=5)
print(f"\n - 각 폴드별 R² 점수: {scores}")
print(f" - 교차 검증 평균 R² 점수: {np.mean(scores):.4f}")
print(f" - 교차 검증 R² 점수의 표준편차: {np.std(scores):.4f}")
