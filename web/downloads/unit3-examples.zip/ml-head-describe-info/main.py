import pandas as pd
data = {'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank'],
        'Score': [90, 85, 78, 92, 65, 70],
        'City': ['Seoul', 'Busan', 'Seoul', 'Jeju', 'Busan', 'Seoul']}

df = pd.DataFrame(data)
print("--- 데이터프레임 상위 3행 (df.head(3)) ---")
print(df.head(3))

print("\n--- 숫자 데이터 통계 요약 (df.describe()) ---")
print(df.describe())

print("\n--- 데이터프레임 요약 정보 (df.info()) ---")
df.info()
