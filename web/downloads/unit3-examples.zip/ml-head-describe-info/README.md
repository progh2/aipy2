# 교과서 91~93쪽 head_describe_info.py — head·describe·info

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 pandas를 설치하세요.

교과서 표기(mean 79.00, std 9.92)는 같은 코드의 실제 실행값(mean 80.00, std 10.94)과 다릅니다 — 이 페이지는 실제 실행값을 싣습니다. dtype 표시도 pandas 버전에 따라 object/str로 다를 수 있습니다.
