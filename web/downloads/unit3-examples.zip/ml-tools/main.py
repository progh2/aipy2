import numpy as np
import pandas as pd
values = np.array([10, 20, 30])
print(values + 5)
print(np.concatenate(([1, 2], [3, 4])))
df = pd.DataFrame({"name": ["A", "B", "C"], "score": [75, 90, 85]})
print(df.head())
print(df.describe())
df.info()
