import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt # 그래프 시각화를 위한 라이브러리
from sklearn.datasets import load_breast_cancer       # 유방암 데이터 세트 사용
from sklearn.model_selection import learning_curve # 학습 곡선 생성
from sklearn.linear_model import LogisticRegression

cancer = load_breast_cancer()
X, y = cancer.data, cancer.target
model = LogisticRegression(max_iter=5000, random_state=42, solver='liblinear')

train_sizes, train_scores, test_scores = learning_curve(
    model, X, y, cv=5, n_jobs=-1, train_sizes=np.linspace(0.1, 1.0, 5)
)
train_scores_mean = np.mean(train_scores, axis=1)
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

plt.figure(figsize=(10, 6))                             # 그래프 크기 설정
plt.title("Learning Curve for Logistic Regression") # 그래프 제목
plt.xlabel("Training Examples")                         # x축 라벨
plt.ylabel("Score (Accuracy)")                          # y축 라벨
plt.grid()                                              # 격자선 표시
plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training Score")
plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                  train_scores_mean + train_scores_std, alpha=0.1, color="r")

plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation Score")
plt.fill_between(
    train_sizes, test_scores_mean - test_scores_std,
    test_scores_mean + test_scores_std, alpha=0.1, color="g")

plt.legend(loc="best")                                  # 범례 표시
plt.savefig("learning_curve.png")
