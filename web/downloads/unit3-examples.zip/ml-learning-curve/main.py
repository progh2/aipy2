import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import learning_curve, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
X, y = load_iris(return_X_y=True)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
cv = StratifiedKFold(3, shuffle=True, random_state=42)
sizes, train, valid = learning_curve(model, X, y, train_sizes=[0.4, 0.7, 1.0], cv=cv, shuffle=True, random_state=42, n_jobs=1)
plt.plot(sizes, train.mean(axis=1), "o-", label="Training")
plt.plot(sizes, valid.mean(axis=1), "s--", label="Validation")
plt.xlabel("Training samples")
plt.ylabel("Accuracy")
plt.legend()
plt.savefig("learning-curve.png")
print("Sizes:", sizes)
print("Validation:", np.round(valid.mean(axis=1), 3))
