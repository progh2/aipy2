# 교과서 124~126쪽 learning_curve.py — 학습 곡선으로 과대·과소 적합 진단

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 numpy scikit-learn matplotlib를 설치하세요.

전체 scikit-learn 모델은 PC에서 실행합니다. 브라우저에서는 연결된 원리 실습으로 입력·계산·결과를 먼저 확인하세요. 교과서는 plt.show()로 화면에 띄우지만, 브라우저 실습에서는 matplotlib 백엔드를 Agg로 지정하고 plt.savefig()로 저장한 그림을 보여줍니다 — 이 부분만 교과서 코드에 추가했습니다.
