import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
X, _ = make_blobs(n_samples=120, centers=3, random_state=42, cluster_std=0.7)
model = KMeans(n_clusters=3, n_init=10, random_state=42)
labels = model.fit_predict(X)
centers = model.cluster_centers_
print("Centers:", centers)
plt.scatter(X[:, 0], X[:, 1], c=labels)
plt.scatter(centers[:, 0], centers[:, 1], marker="X", s=180, c="red")
plt.title("K-means: groups and centers")
plt.savefig("clusters.png")
