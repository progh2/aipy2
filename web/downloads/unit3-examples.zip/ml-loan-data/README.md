# 사서 역할 · 대출 예측에 모을 열

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


