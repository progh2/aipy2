import pandas as pd
from sklearn.model_selection import train_test_split
data_split = {'공부 시간': [2, 3, 5, 4, 6],
              '수면 시간': [7, 6, 8, 7, 7],
              '시험 점수': [60, 70, 85, 75, 90]}
df = pd.DataFrame(data_split)
X = df[['공부 시간', '수면 시간']]
y = df['시험 점수']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
print("\n--- 3. 분할된 데이터의 형태 확인 ---")
print(f" - 훈련 특징 데이터 (X_train) 형태: {X_train.shape}")
print(f" - 테스트 특징 데이터 (X_test) 형태: {X_test.shape}")
print(f" - 훈련 목표 변수 (y_train) 형태: {y_train.shape}")
print(f" - 테스트 목표 변수 (y_test) 형태: {y_test.shape}")
