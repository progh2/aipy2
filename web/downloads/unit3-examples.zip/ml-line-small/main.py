x = [1,2,3,4]
y = [3,5,7,9]
mx,my = sum(x)/len(x),sum(y)/len(y)
w = sum((a-mx)*(b-my) for a,b in zip(x,y))/sum((a-mx)**2 for a in x)
b = my-w*mx
pred = [w*a+b for a in x]
mae = sum(abs(a-p) for a,p in zip(y,pred))/len(y)
print("Learned w, b:",w,b)
print("Prediction at 5:",w*5+b)
print("Training MAE:",mae)
# 훈련 오차 0이 새 데이터에서의 정확성을 보장하지는 않습니다.
