import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
frame = pd.DataFrame({"fruit": ["apple", "banana", "apple"]})
frame.to_excel("fruit.xlsx", index=False)
print(pd.read_excel("fruit.xlsx").head())
sns.countplot(data=frame, x="fruit")
plt.savefig("fruit.png")
