models = [
    ("로지스틱 회귀", "스팸/정상 확률", "분류"),
    ("선형 회귀", "다음 날 대출 권수", "회귀"),
    ("k-NN", "품종 이름", "분류"),
    ("결정 트리", "조건으로 나눈 범주", "분류"),
]
for name, output, kind in models:
    print(f"{name:8} → {output:14} ({kind})")
print("LogisticRegression은 분류 문제에 씁니다.")
