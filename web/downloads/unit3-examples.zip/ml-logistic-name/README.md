# 이름에 회귀가 있어도 분류인 모델

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


