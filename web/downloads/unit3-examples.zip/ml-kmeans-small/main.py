values = [1,2,3,8,9,10]
centers = [1.,8.]
for step in range(4):
    groups = [[],[]]
    for value in values:
        index = min(range(2),key=lambda i:abs(value-centers[i]))
        groups[index].append(value)
    new_centers = [sum(group)/len(group) if group else centers[i] for i,group in enumerate(groups)]
    print("Step",step,"groups:",groups,"centers:",new_centers)
    if new_centers == centers:
        break
    centers = new_centers
