from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
y_true = [1, 0, 1, 1, 0, 0]
y_pred = [1, 1, 1, 0, 0, 0]
print("rows=true, columns=predicted; labels=[0,1]")
print(confusion_matrix(y_true, y_pred, labels=[0, 1]))
for metric in [accuracy_score, precision_score, recall_score, f1_score]:
    print(metric.__name__, metric(y_true, y_pred))
