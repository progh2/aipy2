import pandas as pd
import numpy as np

data_missing = {'Name': ['Alice', 'Bob', np.nan],
                'Score': [90, np.nan, 70],
                'City': ['Seoul', 'Busan', 'Seoul']}

df_missing = pd.DataFrame(data_missing)
print("결측치 확인 (각 열의 결측치 개수):")
print(df_missing.isnull().sum())

df_dropna_row = df_missing.dropna(axis=0)
print("\n결측치가 있는 행 제거 후 데이터:")
print(df_dropna_row)

# 결측치를 0으로 채우기
df_fill_zero = df_missing.fillna(0)
print("\n결측치를 0으로 채운 후 데이터:")
print(df_fill_zero)

# Name 칼럼의 결측치를 'Unknown'으로 채우기
df_fill_unknown_name = df_missing.fillna({'Name': 'Unknown'})
print("\nName 결측치를 'Unknown'으로 채운 후 데이터:")
print(df_fill_unknown_name)

# 'Score' 열의 평균값으로 결측치 채우기
score_mean = df_missing['Score'].mean()
df_fill_mean = df_missing.fillna({'Score': score_mean})
print(f"\n'Score' 결측치를 평균({score_mean:.2f})으로 채운 후 데이터:")
print(df_fill_mean)

# 'Score' 열의 중앙값으로 결측치 채우기
score_median = df_missing['Score'].median()
df_fill_median = df_missing.fillna({'Score': score_median})
print(f"\n'Score' 결측치를 중앙값({score_median:.2f})으로 채운 후 데이터:")
print(df_fill_median)
