# 교과서 93~96쪽 missing_values.py — 결측치 확인·제거·채우기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 pandas numpy를 설치하세요.


