import math
train = [10, 20, 30]
test = [50]
mean = sum(train)/len(train)
std = math.sqrt(sum((v-mean)**2 for v in train)/len(train))
low, high = min(train), max(train)
def standardize(v):
    return (v-mean)/std if std else 0
def normalize(v):
    return (v-low)/(high-low) if high!=low else 0
print("Training mean:",mean)
print("Training standardized:",[round(standardize(v),3) for v in train])
print("Test standardized:",[round(standardize(v),3) for v in test])
print("Test normalized:",[normalize(v) for v in test])
