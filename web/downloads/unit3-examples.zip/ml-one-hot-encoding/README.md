# 교과서 100~101쪽 one_hot_encoding.py — 원-핫 인코딩

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 pandas를 설치하세요.


