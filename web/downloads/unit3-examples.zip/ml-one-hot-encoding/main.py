import pandas as pd

data_onehot = {'도시': ['서울', '부산', '서울', '제주', '부산'],
               '직업': ['학생', '직장인', '직장인', '학생', '학생']}
df_onehot = pd.DataFrame(data_onehot)
print(" - 원본 데이터")
print(df_onehot)

df_encoded = pd.get_dummies(df_onehot, columns=['도시', '직업'], drop_first=True, dtype=int)
print("\n--- 2. 원-핫 인코딩된 데이터 ---")
print(df_encoded)
