from collections import Counter
# 입력값과 클래스가 있는 작은 학습 자료입니다.
training = [(1,"A"),(2,"A"),(4,"B"),(5,"B"),(8,"B")]
x = 3.5
k = 3
neighbors = sorted(training,key=lambda row:abs(row[0]-x))[:k]
prediction = Counter(label for _,label in neighbors).most_common(1)[0][0]
print("Input:",x,"k:",k)
print("Neighbors:",neighbors)
print("Prediction:",prediction)
