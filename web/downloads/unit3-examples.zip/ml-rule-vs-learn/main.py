def password_ok(password):
    return len(password) >= 8

spam_tokens = ["free", "winner", "prize"]

def looks_like_spam(text):
    words = text.lower().split()
    return any(token in words for token in spam_tokens)

print("규칙 기반 비밀번호:", password_ok("abc"), password_ok("longpass"))
print("데이터에서 본 단어:", looks_like_spam("Winner prize now"), looks_like_spam("숙제 제출합니다"))
