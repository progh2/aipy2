# 규칙으로 쓰기 vs 데이터에서 배우기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


