samples = list(range(9))
folds = [samples[i:i+3] for i in range(0,9,3)]
for i, validation in enumerate(folds):
    training = [v for j,fold in enumerate(folds) if j!=i for v in fold]
    print("Fold",i,"train:",training,"validation:",validation)
    assert not set(training)&set(validation)
print("최종 테스트 자료는 이 묶음들과 별도로 보관합니다.")
