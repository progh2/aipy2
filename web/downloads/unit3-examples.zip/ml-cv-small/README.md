# 웹 원리 · 교차 검증의 역할 바꾸기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.

작은 데이터로 핵심 원리를 직접 계산합니다. scikit-learn API 실행과 구별되는 학습용 구현입니다.
