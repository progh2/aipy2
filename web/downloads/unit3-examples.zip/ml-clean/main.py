import pandas as pd
frame = pd.read_csv("scores.csv")
print(frame.head())
print("Missing:", frame.isna().sum())
print("Drop missing:", frame.dropna())
# 이 예제는 탐색용 표입니다. 예측 모델에서는 분할 후 훈련 데이터로 통계량을 구합니다.
median = frame["score"].median()
filled = frame.fillna({"name": "Unknown", "score": median})
print("Filled:", filled)
print("Outside score range:", filled[(filled.score < 0) | (filled.score > 100)])
