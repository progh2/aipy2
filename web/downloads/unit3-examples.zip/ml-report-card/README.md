# 재현 가능한 보고서 카드

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


