values = [1, 2, 3, 18, 19, 21]
cut = (min(values) + max(values)) / 2
low = [v for v in values if v < cut]
high = [v for v in values if v >= cut]
print("기준:", cut)
print("묶음 0:", low)
print("묶음 1:", high)
print("0과 1은 이름일 뿐 순위가 아닙니다.")
