# 정답 없이 가까운 값 묶기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


