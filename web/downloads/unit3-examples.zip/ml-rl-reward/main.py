reward = {"출구": 100, "벽": -10, "이동": -1, "제자리": -2}

def step(kind):
    return reward[kind]

path = ["이동", "이동", "벽", "이동", "출구"]
total = sum(step(kind) for kind in path)
print("경로:", path)
print("누적 보상:", total)
print("제자리만 반복하면:", step("제자리") * 5)
