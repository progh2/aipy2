# 교과서 88~89쪽 matplot_exam.py — Seaborn 막대그래프

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 matplotlib seaborn pandas를 설치하세요.

교과서는 plt.show()로 화면에 띄우지만, 브라우저 실습에서는 plt.savefig()로 저장한 그림을 결과 아래에 보여줍니다(매트플롯립 백엔드도 Agg로 지정) — 이 두 줄만 교과서 코드에 추가했습니다.
