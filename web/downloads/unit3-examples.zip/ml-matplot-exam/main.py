import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

data_for_plot = pd.DataFrame({'fruits': ['apple', 'banana', 'apple']})

# Seaborn으로 막대 그래프 그리기(각 과일 개수)
plt.figure(figsize=(8, 6))
sns.countplot(x='fruits', data=data_for_plot)
plt.savefig("matplot_exam.png")
