import random
samples = list(range(10))
random.Random(42).shuffle(samples)
train, validation, test = samples[:6], samples[6:8], samples[8:]
print("Training:", train)
print("Validation:", validation)
print("Test:", test)
