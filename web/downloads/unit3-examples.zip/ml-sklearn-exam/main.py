from sklearn.tree import DecisionTreeClassifier
import numpy as np

# 학습 데이터
X_study = np.array([[1], [3]])   # 공부 시간
y_pass = np.array([0, 1])        # 합격 여부

# 모델 만들고 학습
model = DecisionTreeClassifier()
model.fit(X_study, y_pass)

# 새로운 공부 시간으로 예측
prediction = model.predict(np.array([[2]]))
print(f"공부 시간 2시간일 때 예측: {prediction[0]}")
