# 딥 블루와 ImageNet은 같은 접근이 아니다

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


