import pandas as pd
from sklearn.datasets import load_breast_cancer   # 유방암 데이터 세트
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
                                        # 모델 성능 평가 지표 함수들 임포트

cancer = load_breast_cancer()
X = pd.DataFrame(cancer.data, columns=cancer.feature_names)
y = pd.Series(cancer.target)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,
                                    random_state=42) # stratify=y는 생략(간소화 목적)

model = LogisticRegression(max_iter=5000, random_state=42, solver='liblinear')
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

conf_matrix = confusion_matrix(y_test, y_pred)
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
print("\n - 혼동 행렬:\n", conf_matrix)
print(f" - 정확도: {accuracy:.4f} - 정밀도: {precision:.4f}")
print(f" - 재현율: {recall:.4f} - F1 점수: {f1:.4f}")
