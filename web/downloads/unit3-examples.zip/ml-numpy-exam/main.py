import numpy as np
my_array = np.array([10, 20, 30])
print("NumPy 배열:", my_array)

result = my_array + 5
print("5를 더한 결과:", result)

# 여러 개의 배열 합치기
array_part1 = np.array([1, 2])
array_part2 = np.array([3, 4])
combined_array = np.concatenate((array_part1, array_part2))
print("\n합쳐진 배열:", combined_array)
