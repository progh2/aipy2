# 교과서 115~117쪽 grid_search_cv.py — GridSearchCV로 K 값 찾기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 scikit-learn numpy를 설치하세요.

전체 scikit-learn 모델은 PC에서 실행합니다. 브라우저에서는 연결된 원리 실습으로 입력·계산·결과를 먼저 확인하세요. 최고 교차 검증 정확도는 scikit-learn 버전에 따라 다를 수 있습니다 — 교과서는 0.9733, 이 실습 환경(scikit-learn 1.9.1)은 0.9800입니다. 최적 K(7)는 동일합니다.
