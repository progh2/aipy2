from sklearn.datasets import load_iris               # 간단한 분류 데이터 세트
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV     # 그리드 서치
import numpy as np                                   # 결과 출력을 위해

iris = load_iris()
X, y = iris.data, iris.target

knn = KNeighborsClassifier()
param_grid = {'n_neighbors': [3, 5, 7]} # K 값만 3, 5, 7로 단순화

grid_search = GridSearchCV(knn, param_grid, cv=5, scoring='accuracy')
grid_search.fit(X, y)

print(f"\n - 최적 하이퍼파라미터: {grid_search.best_params_}")
print(f" - 최고 교차 검증 정확도: {grid_search.best_score_:.4f}")
