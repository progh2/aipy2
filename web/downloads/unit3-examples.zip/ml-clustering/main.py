import pandas as pd
from sklearn.datasets import make_blobs         # 가상 데이터 생성
from sklearn.cluster import KMeans              # K-평균 군집화 모델
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                 # 시각화를 위한 라이브러리
import numpy as np                              # 수치 연산을 위한 라이브러리

X, y_true = make_blobs(n_samples=300, n_features=2, centers=4, cluster_std=0.60,
                        random_state=42)
print(" - 생성된 데이터 형태 (X):", X.shape)
print(" - 생성된 데이터 미리보기 (상위 3개):\n", pd.DataFrame(X, columns=['Feature_1', 'Feature_2']).head(3))

kmeans = KMeans(n_clusters=4, init='k-means++', max_iter=300, random_state=42,
                n_init=10)
kmeans.fit(X)
cluster_labels = kmeans.labels_
print(f" - 각 데이터 포인트의 할당된 군집 레이블 (일부): {cluster_labels[:10]}")

centroids = kmeans.cluster_centers_
print(f" - 각 군집의 중심점:\n {centroids}")
print(f" - 군집 내 응집도: {kmeans.inertia_:.2f}")

plt.figure(figsize=(10, 7))
scatter = plt.scatter(X[:, 0], X[:, 1], c=cluster_labels, cmap='viridis', s=50, alpha=0.8)
plt.scatter(centroids[:, 0], centroids[:, 1], s=200, marker='X', c='red',
            edgecolor='black', label='Centroids')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.savefig("clustering.png")
