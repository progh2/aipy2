import pandas as pd
from sklearn.preprocessing import MinMaxScaler

data_norm = {'Feature1': [10, 20, 30, 40],
             'Feature2': [100, 200, 300, 400]}
df_norm = pd.DataFrame(data_norm)
print("--- 원본 데이터 (정규화 전) ---")
print(df_norm)

scaler_minmax = MinMaxScaler()
df_normalized = pd.DataFrame(scaler_minmax.fit_transform(df_norm), columns=df_norm.columns)
print("\n--- 정규화된 데이터 ---")
print(df_normalized)
