# 규칙을 쓰는 편이 나은 문제

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


