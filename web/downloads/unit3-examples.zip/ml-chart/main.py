import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from collections import Counter
counts = Counter(["apple", "banana", "apple", "pear", "banana", "apple"])
plt.bar(list(counts), list(counts.values()))
plt.ylabel("Count")
plt.title("Fruit frequency")
plt.savefig("frequency.png")
print(dict(counts))
