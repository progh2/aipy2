# 빈도표를 막대그래프로

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 matplotlib를 설치하세요.

실제 Python이 저장한 PNG를 실행 결과 아래에서 확인할 수 있습니다.
