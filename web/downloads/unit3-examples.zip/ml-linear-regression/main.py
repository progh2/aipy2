import pandas as pd
from sklearn.datasets import load_diabetes            # 예제 데이터 세트(당뇨병 데이터)
from sklearn.model_selection import train_test_split  # 데이터 분할
from sklearn.linear_model import LinearRegression      # 선형 회귀 모델

diabetes = load_diabetes()
X = pd.DataFrame(diabetes.data, columns=diabetes.feature_names)    # 특징
y = pd.Series(diabetes.target)              # 질병 진행도: 연속적인 숫자 값
print(" - 특징(X) 데이터 미리보기 (상위 5개) \n", X.head())
print("\n - 목표 변수(y) 미리보기 (상위 3개):\n", y.head(3))
print(f" - 원본 데이터 형태: {X.shape}, {y.shape}")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
print(f" - 훈련 데이터 형태: {X_train.shape}, {y_train.shape}")
print(f" - 테스트 데이터 형태: {X_test.shape}, {y_test.shape}")

linear_model = LinearRegression()
linear_model.fit(X_train, y_train)                # 모델 학습
print(f" - 모델의 계수: {linear_model.coef_}")
print(f" - 모델의 절편: {linear_model.intercept_:.4f}")

y_pred = linear_model.predict(X_test)
print(" - 테스트 데이터에 대한 예측 결과 (일부):")
print(y_pred[:5])
