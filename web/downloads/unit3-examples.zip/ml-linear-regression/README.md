# 교과서 106~108쪽 linear_regression.py — 당뇨병 데이터로 선형 회귀

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 scikit-learn pandas를 설치하세요.

전체 scikit-learn 모델은 PC에서 실행합니다. 브라우저에서는 연결된 원리 실습으로 입력·계산·결과를 먼저 확인하세요. X.head() 출력은 pandas가 화면 폭에 맞춰 가운데 열을 생략(...)해 보여줄 수 있습니다 — 교과서는 지면 폭이 넓어 10개 열을 모두 보여줍니다. 계수·절편·예측값은 동일합니다.
