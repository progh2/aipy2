import pandas as pd
data = {'이름': ['철수', '영희'], '점수': [85, 92]}
my_df = pd.DataFrame(data)
print("학생 점수표:")
print(my_df)
print("\n'점수' 칼럼:\n", my_df['점수'])
