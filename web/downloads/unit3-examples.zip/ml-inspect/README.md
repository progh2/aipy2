# 검사원 역할 · 입력과 예측 출력

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


