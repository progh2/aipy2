truth = [1,0,1,1,0,0]
probability = [.9,.8,.6,.4,.3,.1]
threshold = .5
pred = [int(p>=threshold) for p in probability]
tp = sum(a==1 and b==1 for a,b in zip(truth,pred))
fp = sum(a==0 and b==1 for a,b in zip(truth,pred))
fn = sum(a==1 and b==0 for a,b in zip(truth,pred))
tn = sum(a==0 and b==0 for a,b in zip(truth,pred))
precision = tp/(tp+fp) if tp+fp else None
recall = tp/(tp+fn) if tp+fn else None
print("TP FP FN TN:",tp,fp,fn,tn)
print("Precision:",precision,"Recall:",recall)
