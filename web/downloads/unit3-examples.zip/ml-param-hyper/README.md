# 배우는 값과 미리 정하는 값

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


