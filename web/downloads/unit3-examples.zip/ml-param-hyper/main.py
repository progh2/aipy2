from collections import Counter
training = [(1, "A"), (2, "A"), (8, "B"), (9, "B")]
x = 3
k = 3
neighbors = sorted(training, key=lambda row: abs(row[0] - x))[:k]
voted = Counter(label for _, label in neighbors).most_common(1)[0][0]
print("하이퍼파라미터 k:", k)
print("가까운 이웃:", neighbors)
print("이 데이터에서 정해진 예측:", voted)
