# 같은 행의 X와 y를 맞추기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


