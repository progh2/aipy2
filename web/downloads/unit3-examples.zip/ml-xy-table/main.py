rows = [
    (["월", 12], 15),
    (["화", 15], 14),
    (["수", 30], 28),
]
X = [row[0] for row in rows]
y = [row[1] for row in rows]
print("샘플 수:", len(X), "특성 수:", len(X[0]))
print("X 형태: (샘플 수, 특성 수) =", (len(X), len(X[0])))
print("y 형태: (샘플 수,) =", (len(y),))
print("1번 행 X:", X[1], "→ y:", y[1])
