import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
train = np.array([[10., 1.], [20., np.nan], [30., 3.]])
test = np.array([[50., 2.]])
imputer = SimpleImputer(strategy="median")
train_filled = imputer.fit_transform(train)
test_filled = imputer.transform(test)
for scaler in [MinMaxScaler(), StandardScaler()]:
    print(type(scaler).__name__)
    print(scaler.fit_transform(train_filled))
    print("Test:", scaler.transform(test_filled))
encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
print(encoder.fit_transform([["Seoul"], ["Busan"], ["Seoul"]]))
print("Unseen city:", encoder.transform([["Jeju"]]))
