import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np                                 # 통계량 확인을 위해 사용

data = {
    'Feature1': [10, 20, 30, 40, 50],
    'Feature2': [100, 200, 50, 150, 250],
    'Feature3': [1, 2, 3, 100, 4]                 # 이상치인 큰 값을 포함
}
df = pd.DataFrame(data)

scaler_standard = StandardScaler()
df_standardized = scaler_standard.fit_transform(df) # 데이터에 표준화 적용
df_standardized = pd.DataFrame(df_standardized, columns=df.columns)
print(df_standardized)

print("각 특성의 평균 :", scaler_standard.mean_)
print("각 특성의 표준편차 :", np.sqrt(scaler_standard.var_))
