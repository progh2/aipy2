actual = [10, 12, 8, 14]
baseline = [11, 11, 11, 11]
model = [10, 11, 9, 12]

def mae(true, pred):
    return sum(abs(a - p) for a, p in zip(true, pred)) / len(true)

print("평균 예측 MAE:", mae(actual, baseline))
print("모델 MAE:", mae(actual, model))
print("성공?", mae(actual, model) < mae(actual, baseline))
