# 교과서 90~91쪽 read_data.py — CSV·Excel 불러오기

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.
먼저 가상환경에서 `python -m pip install -r requirements.txt`로 pandas openpyxl를 설치하세요.

교과서는 텍스트 편집기·엑셀로 미리 만든 data.csv·data.xlsx를 코랩에 업로드해 읽습니다. 이 예제는 같은 내용을 코드 앞 두 줄에서 직접 만든 뒤 그대로 읽어 들입니다 — 그 두 줄만 교과서 코드에 추가했습니다. Excel 저장에 openpyxl이 필요해 PC/코랩에서 실행하세요.
