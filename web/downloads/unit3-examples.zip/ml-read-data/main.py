import pandas as pd

# 교과서는 텍스트 편집기·엑셀로 만든 data.csv/data.xlsx를 코랩에 업로드해서 읽습니다.
# 웹 실습에서는 같은 내용을 코드로 먼저 만든 뒤 그대로 읽어 들입니다.
with open('data.csv', 'w', encoding='utf-8') as f:
    f.write('Name, Score\nAlice, 90\nBob, 85\n')
pd.DataFrame({'Name': ['Alice', 'Bob'], 'Score': [90, 85]}).to_excel('data.xlsx', index=False)

df_csv = pd.read_csv('data.csv')
print("CSV에서 불러온 데이터:")
print(df_csv)

df_excel = pd.read_excel('data.xlsx')
print("\nExcel에서 불러온 데이터:")
print(df_excel)
