# 범주를 맞히나, 숫자를 맞히나

이 폴더를 VS Code로 열고 `python main.py`로 실행하세요.


