import pandas as pd
from sklearn.model_selection import train_test_split # 데이터 분할 함수
from sklearn.linear_model import LinearRegression      # 예시 모델 (선형 회귀)
from sklearn.datasets import load_diabetes             # 예제 데이터 세트

diabetes = load_diabetes()
X = pd.DataFrame(diabetes.data, columns=diabetes.feature_names) # 특징 데이터
y = pd.Series(diabetes.target)   # 목표 변수 데이터

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
print(" - 훈련 데이터 형태:", X_train.shape, y_train.shape)
print(" - 테스트 데이터 형태:", X_test.shape, y_test.shape)

linear_model = LinearRegression()
linear_model.fit(X_train, y_train)             # 훈련 데이터로 학습
r2_train = linear_model.score(X_train, y_train) # 훈련 데이터 R²
r2_test = linear_model.score(X_test, y_test)   # 테스트 데이터 R²
print(" - 훈련 데이터 R²:", r2_train)          # 일반적으로 테스트 데이터보다 높음
print(" - 테스트 데이터 R²:", r2_test)          # 훈련 데이터보다 낮음 (일반화 성능)
