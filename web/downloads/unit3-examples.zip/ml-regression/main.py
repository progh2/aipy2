from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)
print("Train R2:", model.score(X_train, y_train))
print("Test MAE:", mean_absolute_error(y_test, pred))
print("Test MSE:", mean_squared_error(y_test, pred))
print("Test R2:", r2_score(y_test, pred))
